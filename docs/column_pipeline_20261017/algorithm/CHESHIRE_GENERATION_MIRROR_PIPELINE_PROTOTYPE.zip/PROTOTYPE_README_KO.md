# 체셔 장식·세대 분류·반사 component 파이프라인 prototype

이번 묶음은 새 전체 적용에 실제 사용한 세대 분류, coarse Mandel→실제 CC→fine Mandel, 종이 원리의 절단·반사·Boolean 접합 및 실제 Tissue adapter를 추가한 코드 묶음입니다. 기존22와 이전 wholeCC1 시험은 그대로 보존했습니다.

## 재사용 가능한 코어와 특정 기둥 adapter

- `src/cheshire/history_classifier.py`: 동일 material ancestry의 실제 단계별 형상·법선·authored residual과 prior를 받아 새 연속 SOURCE5 weights와 evidence score를 계산합니다. 입력의 정점 번호를 특징 발생 세대라고 해석하지 않습니다.
- `src/cheshire/paper_component_kernel.py`: 유효한 유한3D solid mesh와 절단 plane 순서를 받아 실제 halfspace cut→reflection→Manifold Boolean union→largest area component를 수행합니다.
- `src/cheshire/ornament_subdivision.py`: 실제 neutral CC와 V/E/F 계보를 out-of-core로 계산합니다.
- `src/cheshire/adaptive_ornament.py`, `ornament_analysis.py`: 기존 두 입력 형상에서 검증한 장식 분석·정규 변위 및 안전 회복 코어입니다. 그 기존 CLI·작은 입력·검증 기록도 보존했습니다.
- `generation_mirror/whole_column_fixture.py` 및 관련 scripts는 이번 체셔의 stage 경로와 exact lineage를 연결하는 실행 fixture입니다. 다른 기둥에서는 mesh, 선택적 stage history와 ancestry, 역할/끝부분/주름 보호 mask, 물리 단위를 연결하는 adapter/config가 필요합니다. 코드의 현재 체셔 faceID/경로를 다른 형상에 그대로 적용하는 API라고 주장하지 않습니다.

## 입력과 실제 적용

기본 입력은 유효한 shape mesh와 물리 단위입니다. 다세대 분류에는 같은 material point의 단계별 위치·법선, 실제 authored-minus-neutral 잔차, prior와 correspondence validity가 추가로 필요합니다. history가 없거나 불충분하면 prior를 유지합니다. 반사 component는 닫힌 oriented triangle solid를 받으며, 실제 CC 결과와 whole용 높이 그래프를 구별합니다. Tissue의 새 생성에는 설치된 Blender Tissue addon이 필요합니다. 제공된 실제 generated height grid는 plugin을 재실행하지 않고 downstream mapping에 사용할 수도 있습니다.

일반 장식 전이의 작은 두 입력 CLI 실행법은 `docs/ADAPTIVE_ORNAMENT.md`에 있습니다. 새 전체 fixture는 외부 원본 NESTED·G6/G7 stage/lineage assets를 요구하므로 이 작은 ZIP만으로 7M 기둥 전체를 독립 재생성할 수 있다고 주장하지 않습니다. 14M 정점/28M triangle의 새 전체 모델은 별도 PLY로 제공합니다.

## 검증과 범위

새 SOURCE G3 23,736faces 중 dominant3,212개가 변경됐고, 21,280 material 표본에서 coarse 실제CC·새 fine·새 paper Tissue가 최종 cap/allow/gain 뒤에도 실제 기여함을 독립 확인했습니다. full native fan은 방향 역전0·퇴화0입니다. 내부 control quad의 대체 diagonal 삼각화에는30,704역전이 있어 이 모델은 실제 검사한 native centroid-fan triangle PLY로만 내보냅니다.

주요 주름486profile의 유지율 중앙값은99.855%이며 국소10개 review flags가 남아 있습니다. 보호22 core 좌표 exact와 모든 profile이 완전히 같다는 주장은 구별합니다. SOURCE oval11115/crossbar10811에는 이번 새 history mask가 paper Tissue를 배치하지 않고 새 Mandel을 적용했습니다. 다른 SOURCE/attached 영역에서 새 paper Tissue는 실제 기여합니다.

원paper component의 genus119인 닫힌3D asset을 포함합니다. 전체기둥에는 exact topmost-ray 단일값 graph→실제 Tissue→G3/G7 UV pullback relief를 적용했습니다. component의 구멍·핸들·overhang topology 전체를 본체에 Boolean union한 결과가 아닙니다. 열린 Tissue 실험은 수행하지 않았습니다.

기존 작은 CLI 재실행 bitexact 및 새 classifier scale/rotation/ID 보존 검증은 prototype 범위의 근거입니다. 이 ZIP의 새 전체 fixture를 다른 실제 기둥에 end-to-end 적용해 검증했다고 주장하지 않습니다. 요철·복잡함 유지와 연결의 유기화를 함께 평가하며 자동 채택 전입니다.
