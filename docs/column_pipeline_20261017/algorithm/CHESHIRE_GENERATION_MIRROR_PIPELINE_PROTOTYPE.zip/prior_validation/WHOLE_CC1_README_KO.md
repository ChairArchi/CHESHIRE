# 주름 보존 장식 파이프라인 + 실제 CC1 프로토타입

재사용 API: docs/ADAPTIVE_ORNAMENT.md
분석: cheshire.ornament_analysis.analyze_ornament_shape
장식: cheshire.adaptive_ornament.apply_adaptive_ornament
실제 디스크 기반 분할: cheshire.ornament_subdivision.prepare_cc1

현재 프로젝트의 NumPy/SciPy/COMPAS 환경으로 실행합니다. 새 환경은 pyproject.toml의 task32 extra를 참고하세요.

```powershell
python -B examples/adaptive_ornament_transfer.py --host samples/straight_fluted_host.npz --profile samples/mandel_profile.npz --radius 0.28 --recipe samples/recipe.json --output trial01
blender --background --factory-startup --python tools/render_geometry.py -- --input trial01/geometry.npz --output trial01_views
```

host를 samples/twisted_tapered_host.npz로 바꾸어 같은 파이프라인을 다른 기둥에 적용합니다. 실제 캐시 만델벌브 경계와 실제 캐시 Tissue 컴포넌트를 사용하며, 새 Tissue 플러그인 실행을 주장하지 않습니다.

CC1 코어에는 특정 기둥 면 번호/파일 경로가 없습니다. 새로운 xyz/quads/물리 좌표/보호 속성을 전달하면 V/E/F 새 좌표와 정확 자식 면 및 운반된 속성을 돌려줍니다. 주름 보호 혼합과 면 방향 검사는 별도 단계이며 raw CC 결과를 자동 승인하지 않습니다.

whole_trial_adapter는 이번 기존22 전체 시험을 재현한 실행 기록입니다. 이 어댑터의 E: 입력 경로는 현재 프로젝트 데이터에 의존합니다. 전체 28M 사각 면 모델은 별도 PLY로 제공하며 이 작은 코드 묶음에는 포함하지 않았습니다.

현재 전체 시험은 1회 실제 분할과 주름 보호/국소 안전 회복입니다. 새 만델벌브를 재주입한 버전이 아닙니다. 기존22 원본을 보존했습니다. validation의 실행·기하·큰 주름 비교 결과를 함께 기록합니다.
