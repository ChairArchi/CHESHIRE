"""Render every saved CC1 control and quad, with Blender quad tessellation.

No subdivision, smoothing of coordinates, decimation, material resampling,
normal maps, or face-centre fan insertion is performed by this renderer.
Optional smooth-gray changes normal interpolation only. The first render is
always a flat close view for bounded GPU/style review.
"""
from pathlib import Path
import argparse,importlib.util,json,shutil,sys,time
sys.dont_write_bytecode=True
import bpy
import numpy as np

BASE=Path(r'E:\CHESHIRE_DATA\experiments\fold_aligned_mandel_20261015')
CURRENT22=BASE/'variant22_flow_corrected_visible_relief_whole_hybrid_20261016'
RESEARCH=Path(r'E:\CHESHIRE_DATA\experiments\interleaved_mandel_subdivision_20261016')
INDEX_PATH=RESEARCH/'existing22_color1800/work/classification_cache/native_material_indices.npy'
CLASS_PATH=CURRENT22/'COLOR_ZONES_REVIEW/CLASSIFICATION_RECEIPT.json'
spec=importlib.util.spec_from_file_location('whole_cc1_trusted_scene',BASE/'render_spine_review_v2.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
render,fast,digest,write=m.render,m.fast,m.digest,m.write
ah=render.scaffold.array_hash
NV0,NE0,NQ0=7002114,14004224,7002112
PALETTE=[('\ubcf4\ud638\ub41c \ub05d\ubd80\ubd84',(.30,.32,.35,1)),
 ('\uc644\ub9cc\ud55c \uba74',(.20,.55,.90,1)),
 ('\uc57d\ud55c \uc8fc\ub984\u00b7\uc804\uc774',(.025,.48,.40,1)),
 ('\uac15\ud558\uace0 \ubc29\ud5a5\uc774 \uc774\uc5b4\uc9c0\ub294 \uc8fc\ub984',(.015,.09,.30,1)),
 ('\ub465\uadfc \uc735\uae30',(.75,.46,.035,1)),
 ('\uc5ec\ub7ec \ubc29\ud5a5\uc774 \ub9cc\ub098\ub294 \ud6c4\ubcf4 \ubd80\uc704',(.55,.07,.34,1)),
 ('Tissue \uc801\uc6a9 \ub300\uc0c1 \uc601\uc5ed',(.95,.23,.025,1)),
 ('\uc8fc\uc694 \uc8fc\ub984 \uc911\uc2ec \ubcf4\ud638',(.08,.65,.12,1))]


def disk(folder,name,shape,dtype):
    return np.lib.format.open_memmap(folder/(name+'.npy'),mode='w+',dtype=dtype,shape=shape)


def use_gpu(scene):
    pref=bpy.context.preferences.addons['cycles'].preferences
    for backend in ('OPTIX','CUDA'):
        try:pref.compute_device_type=backend;pref.get_devices()
        except Exception:continue
        devices=[d for d in pref.devices if d.type==backend]
        if devices:
            for d in pref.devices:d.use=d.type==backend
            scene.cycles.device='GPU'
            return dict(backend=backend,devices=[d.name for d in devices])
    raise RuntimeError('No usable research GPU; do not silently use CPU.')


def signature(obj,work,smooth_expected):
    mesh=obj.data
    x=disk(work,'readback_xyz',(len(mesh.vertices),3),np.float32)
    q=disk(work,'readback_quads',(len(mesh.polygons),4),np.int32)
    flags=np.empty(len(mesh.polygons),bool)
    mesh.vertices.foreach_get('co',x.ravel())
    mesh.loops.foreach_get('vertex_index',q.ravel())
    mesh.polygons.foreach_get('use_smooth',flags)
    count=int(np.count_nonzero(flags))
    if count!=(len(flags) if smooth_expected else 0):raise ValueError('Shading flag readback differs.')
    result=dict(vertices=len(mesh.vertices),quads=len(mesh.polygons),loops=len(mesh.loops),
        xyz_float32_sha256=ah(x),quad_indices_int32_sha256=ah(q),
        edges=len(mesh.edges),modifiers=len(obj.modifiers))
    if result['edges'] or result['modifiers']:raise ValueError('Unexpected edge graph or modifier.')
    return result,dict(smooth_polygons=count,flat_polygons=len(flags)-count,flags_sha256=ah(flags))


def set_shading(obj,smooth):
    obj.data.polygons.foreach_set('use_smooth',np.full(len(obj.data.polygons),smooth,bool))
    obj.data.update_tag();obj.update_tag(refresh={'DATA'});bpy.context.view_layer.update()


def color_materials(obj,indices):
    obj.data.materials.clear()
    for number,(label,rgba) in enumerate(PALETTE):
        mat=bpy.data.materials.new(str(number)+': '+label);mat.use_nodes=True
        nodes=mat.node_tree.nodes;nodes.clear();links=mat.node_tree.links
        out=nodes.new('ShaderNodeOutputMaterial');bs=nodes.new('ShaderNodeBsdfPrincipled')
        bs.inputs['Base Color'].default_value=rgba;bs.inputs['Roughness'].default_value=.86
        em=nodes.new('ShaderNodeEmission');em.inputs['Color'].default_value=rgba;em.inputs['Strength'].default_value=.8
        mix=nodes.new('ShaderNodeMixShader');mix.inputs[0].default_value=.20
        links.new(bs.outputs['BSDF'],mix.inputs[1]);links.new(em.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],out.inputs[0])
        obj.data.materials.append(mat)
    obj.data.polygons.foreach_set('material_index',indices)


def material_signature(obj,expected):
    indices=np.empty(len(obj.data.polygons),np.int32)
    obj.data.polygons.foreach_get('material_index',indices)
    result=ah(indices)
    if result!=expected:raise ValueError('Inherited parent classification differs in Blender.')
    return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--xyz',type=Path,required=True)
    p.add_argument('--quads',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--smooth-gray',action='store_true')
    p.add_argument('--close-only',action='store_true')
    args=p.parse_args(sys.argv[sys.argv.index('--')+1:])
    root,out=args.root.resolve(),args.output.resolve()
    sources=[args.xyz.resolve(),args.quads.resolve(),args.receipt.resolve(),INDEX_PATH,CLASS_PATH]
    if not out.is_relative_to(root) or out.exists() or root==CURRENT22:
        raise FileExistsError('Fresh output inside new CC1 root required; original22 remains read-only.')
    if not all(path.is_file() for path in sources):raise FileNotFoundError('Final geometry, receipt, and original color inputs required.')
    if not args.xyz.resolve().is_relative_to(root) or not args.quads.resolve().is_relative_to(root):
        raise ValueError('CC1 source arrays must belong to new CC1 root.')
    started=time.perf_counter();source_hashes={str(path):digest(path) for path in sources}
    x=np.load(args.xyz,mmap_mode='r',allow_pickle=False)
    q=np.load(args.quads,mmap_mode='r',allow_pickle=False)
    if x.shape!=(NV0+NE0+NQ0,3) or x.dtype!=np.dtype('float64') or q.shape!=(4*NQ0,4) or q.dtype!=np.dtype('int64'):
        raise ValueError('Expected every actual CC1 control and child quad in saved V/E/F order.')
    original=json.loads(CLASS_PATH.read_text(encoding='utf-8'))
    indices=np.load(INDEX_PATH,mmap_mode='r',allow_pickle=False)
    if indices.shape!=(len(q),) or indices.dtype!=np.dtype('int32') or ah(indices)!=original['index_sha256']:
        raise ValueError('Exact existing22 quad category transport required.')
    out.mkdir();work=out/'work';work.mkdir();snap=out/'source_snapshot';snap.mkdir()
    for path in (Path(__file__).resolve(),BASE/'render_spine_review_v2.py',m.FAST_PATH,fast.PRESERVED,CLASS_PATH):
        shutil.copyfile(path,snap/path.name)
    parent_q=disk(work,'saved_parent_quads',(NQ0,4),np.int64)
    for start in range(0,NQ0,32768):
        stop=min(start+32768,NQ0);block=q[4*start:4*stop].reshape(-1,4,4)
        parent_q[start:stop]=block[:,:,1]
        if not np.array_equal(block[:,:,3],np.broadcast_to((NV0+NE0+np.arange(start,stop))[:,None],(stop-start,4))):
            raise ValueError('CC1 child-to-parent facepoint IDs differ.')
        if np.any(block[:,:,0]<NV0) or np.any(block[:,:,0]>=NV0+NE0) or not np.array_equal(block[:,:,2],np.roll(block[:,:,0],-1,axis=1)):
            raise ValueError('Actual CC1 previous/next edgepoint cycles differ.')
    if ah(parent_q)!=original['quad_faces_sha256']:raise ValueError('CC1 retained original corners differ from saved G7 connectivity.')
    classification=dict(kind='CURRENT22_PARENT_QUAD_CATEGORIES_TRANSPORTED_TO_ALL_FOUR_CC1_CHILD_QUADS',
        source_receipt=str(CLASS_PATH),source_receipt_sha256=source_hashes[str(CLASS_PATH)],
        source_indices=str(INDEX_PATH),source_indices_file_sha256=source_hashes[str(INDEX_PATH)],
        index_sha256=original['index_sha256'],parent_quad_sha256=ah(parent_q),
        category_quad_counts=original['category_triangle_counts'],palette=[dict(index=i,label_ko=l,rgba=list(c)) for i,(l,c) in enumerate(PALETTE)],
        new_shape_reclassification=False,source5_unchanged=True,Tissue_orange_is_semantic_eligibility_not_equal_height=True,
        rule='Saved CC1 child face 4*parent+i inherits unchanged current22 parent category; exact old-corner/edgepoint/facepoint cycles checked.',
        inputs=original['inputs'])
    write(out/'CLASSIFICATION_RECEIPT.json',classification)
    display_x=disk(work,'display_xyz',x.shape,np.float32)
    display_q=disk(work,'display_quads',q.shape,np.int32)
    for start in range(0,len(x),131072):
        stop=min(start+131072,len(x));block=x[start:stop]
        if not np.isfinite(block).all():raise ValueError('Nonfinite final CC1 coordinates.')
        display_x[start:stop]=block
    for start in range(0,len(q),131072):
        stop=min(start+131072,len(q));block=q[start:stop]
        if np.any(block<0) or np.any(block>=len(x)):raise ValueError('Invalid CC1 control index.')
        display_q[start:stop]=block
    display_expected=dict(xyz_float32_sha256=ah(display_x),quad_indices_int32_sha256=ah(display_q))
    shared=render.scaffold.setup_scene()
    mesh=bpy.data.meshes.new('All exact CC1 controls and child quads')
    print('LOAD_ALL_CC1_CONTROL_QUADS',len(x),len(q),flush=True)
    mesh.vertices.add(len(x));mesh.vertices.foreach_set('co',display_x.ravel())
    mesh.loops.add(4*len(q));mesh.loops.foreach_set('vertex_index',display_q.ravel())
    mesh.polygons.add(len(q))
    starts=disk(work,'loop_starts',(len(q),),np.int32);totals=disk(work,'loop_totals',(len(q),),np.int32)
    for start in range(0,len(q),131072):
        stop=min(start+131072,len(q));starts[start:stop]=4*np.arange(start,stop,dtype=np.int32);totals[start:stop]=4
    mesh.polygons.foreach_set('loop_start',starts);mesh.polygons.foreach_set('loop_total',totals)
    obj=bpy.data.objects.new('Actual whole-column constrained CC1',mesh);bpy.context.collection.objects.link(obj)
    fast.assign_original_material(obj,shared);fast.set_flat_flags(obj)
    scene,camera=shared.setup_scene(900,24);device=use_gpu(scene)
    scene.render.use_persistent_data=True
    binding=render.source_binding()
    before,flat_before=signature(obj,work,False)
    if any(before[k]!=v for k,v in display_expected.items()):raise ValueError('All-control display readback differs from final saved CC1.')
    actual_views={};images=[]
    first_folder=out/'qa_flat'
    av,im=render.scaffold.render_views(scene,camera,{'close_oblique':binding['views']['close_oblique']},first_folder)
    for view in av:render.require_close(av[view],binding['actual_views'][view],'same-current22-camera.'+view)
    qa=dict(kind='ALL_CC1_CONTROL_QUADS_FLAT_CLOSE_GPU_QA',input_files=source_hashes,counts=before,
        display_expected=display_expected,images=im,actual_views=av,device=device,
        all_cc1_controls_and_quads_retained=True,blender_automatic_quad_tessellation=True,
        expected_render_triangles=2*len(q),explicit_native_facecentre_fans=False)
    write(out/'QA_CLOSE_RECEIPT.json',qa)
    print('FULL_QUAD_FLAT_CLOSE_READY',str(first_folder/'close_oblique.png'),flush=True)
    if args.close_only:return
    if args.smooth_gray:
        set_shading(obj,True)
        gray_views=['body_oblique','front','close_oblique']
    else:
        actual_views['gray_close_oblique']=av['close_oblique']
        images.extend([dict(v,path=str(out/'gray'/(v['view']+'.png')),style='gray',shading='flat') for v in im])
        gray_views=['body_oblique','front']
    av,im=render.scaffold.render_views(scene,camera,{v:binding['views'][v] for v in gray_views},out/'gray')
    for view in av:render.require_close(av[view],binding['actual_views'][view],'same-current22-camera.'+view)
    if not args.smooth_gray:
        shutil.copyfile(first_folder/'close_oblique.png',out/'gray/close_oblique.png')
        if digest(first_folder/'close_oblique.png')!=digest(out/'gray/close_oblique.png'):raise ValueError('Copied flat close PNG differs.')
    actual_views.update({'gray_'+k:v for k,v in av.items()})
    images.extend([dict(v,path=str(out/'gray'/(v['view']+'.png')),style='gray',shading='smooth-normal' if args.smooth_gray else 'flat') for v in im])
    if args.smooth_gray:set_shading(obj,False)
    color_materials(obj,indices);material_before=material_signature(obj,classification['index_sha256'])
    scene.cycles.samples=8;scene.view_settings.exposure=-.4
    scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.25
    for name,power in (('Key',16000),('Fill',3000),('Rim',6000)):bpy.data.lights[name].energy=power
    av,im=render.scaffold.render_views(scene,camera,{v:binding['views'][v] for v in ('body_oblique','front')},out/'color')
    for view in av:render.require_close(av[view],binding['actual_views'][view],'same-current22-camera.'+view)
    actual_views.update({'color_'+k:v for k,v in av.items()});images.extend([dict(v,path=str(out/'color'/(v['view']+'.png')),style='color',shading='flat') for v in im])
    after,flat_after=signature(obj,work,False)
    if before!=after or material_signature(obj,material_before)!=material_before:raise ValueError('CC1 geometry or inherited colors changed during rendering.')
    for path,h in source_hashes.items():
        if digest(path)!=h:raise ValueError('Saved geometry or classification input changed during rendering.')
    write(out/'RENDER_RECEIPT.json',dict(kind='ACTUAL_WHOLE_CC1_ALL_CONTROL_QUAD_REVIEW',
        input_files=source_hashes,source_generation_receipt=str(args.receipt.resolve()),
        classification_receipt=str(out/'CLASSIFICATION_RECEIPT.json'),classification_receipt_sha256=digest(out/'CLASSIFICATION_RECEIPT.json'),
        before=before,after=after,flat_before=flat_before,flat_after=flat_after,display_expected=display_expected,
        full_saved_control_geometry=True,all_control_vertices_retained=True,all_control_quads_retained=True,
        unchanged_geometry=True,same_control_geometry_for_all_views=True,geometry_decimation=False,
        material_uv_resampling=False,geometry_smoothing_by_renderer=False,modifiers=[],normal_maps=False,
        control_vertices=len(x),control_quads=len(q),blender_automatic_quad_tessellation=True,
        expected_render_triangles=2*len(q),explicit_native_facecentre_fans=False,
        native_four_fan_qa_triangle_count=4*len(q),quad_tessellation_note='Every saved control and quad is retained. Blender automatically tessellates each quad into two render triangles; this differs from four face-centre fans used for geometry QA.',
        actual_views=actual_views,images=images,palette=classification['palette'],
        shading=dict(gray='normal interpolation' if args.smooth_gray else 'flat',color='flat',final_flat_flags_restored=True),
        conditions=dict(resolution=[900,900],gray_samples=24,color_samples=8,gray_original_scene=True,
                        color_exposure=-.4,color_world_strength=.25,color_key_fill_rim=[16000,3000,6000]),
        device=device,native_loaded_once=True,renderer_sha256=digest(__file__),version=bpy.app.version_string,
        elapsed_seconds=time.perf_counter()-started))
    print('WHOLE_CC1_ALL_QUAD_GRAY3_COLOR2_COMPLETE',str(out),time.perf_counter()-started,flush=True)


if __name__=='__main__':main()
