"""Small exact material-sample macro QA: completed22 G7 versus whole CC1 G8."""
from pathlib import Path
import sys,json,hashlib,csv,time,importlib.util
sys.dont_write_bytecode=True
import numpy as np
HERE=Path(__file__).resolve().parent
OLD=Path(r'E:\CHESHIRE_DATA\experiments\fold_aligned_mandel_20261015\variant22_flow_corrected_visible_relief_whole_hybrid_20261016')
QA=Path(r'E:\CHESHIRE_DATA\experiments\whole_hybrid_flow_qa_20261016')
sys.path.insert(0,str(QA))
import qa_certified_macro_flow as oldqa
from prepare_whole_cc1_20261016 import mapped
UV=np.array([[0.,0.],[1.,0.],[1.,1.],[0.,1.]])
MID=.5*(UV+np.roll(UV,-1,axis=0))
CHILD=np.stack((np.roll(MID,1,axis=0),UV,MID,np.full((4,2),.5)),axis=1)
CENTER=CHILD.mean(axis=1)
TRI=np.stack((CHILD,np.roll(CHILD,-1,axis=1),np.broadcast_to(CENTER[:,None,:],CHILD.shape)),axis=2).reshape(16,3,2)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def load_measurement(description,sources):
 p=Path(description);doc=read(p);sources[str(p)]=sha(p);archive=Path(doc['array_file'])
 desc=doc['tree']['foundation']['measurement'];m={};verified={}
 with np.load(archive,allow_pickle=False) as z:
  for key in ('valid','normal','across_distances','s','confirmed','shoulder_indices','geometric_peak_index','xyz0'):
   spec=desc[key];value=z[spec['npz_key']]
   if list(value.shape)!=spec['shape'] or oldqa.ah(value)!=spec['sha256']:raise ValueError('Selected certified measurement array changed.')
   m[key]=value;verified[key]=spec['sha256']
 return m,dict(archive=str(archive),declared_archive_sha256=doc['array_file_sha256'],selected_array_hashes_freshly_verified=verified)
def sample_component(old,xold,qold,xnew,qnew,nv,ne):
 shape=old['mapped'].shape;valid=old['mapped'].ravel()&(old['triangle_ids'].ravel()>=0);where=np.flatnonzero(valid)
 tri7=old['triangle_ids'].ravel()[where];parent=tri7//4;corner=tri7%4;w7=old['barycentric'].reshape(-1,3)[where]
 query=w7[:,0,None]*UV[corner]+w7[:,1,None]*UV[(corner+1)%4]+w7[:,2,None]*.5
 qp=qold[parent];rows=np.arange(len(where))
 oldtri=np.stack((xold[qp[rows,corner]],xold[qp[rows,(corner+1)%4]],xold[qp].mean(1)),axis=1)
 reconstructed=np.einsum('ni,nij->nj',w7,oldtri)
 expected=old['after_xyz'].reshape(-1,3)[where]
 olderror=float(np.max(np.abs(reconstructed-expected),initial=0))
 if olderror>1e-9:raise ValueError('Saved actual22 sample does not reconstruct actual22 geometry.')
 a=TRI[:,1]-TRI[:,0];b=TRI[:,2]-TRI[:,0];p=query[:,None,:]-TRI[None,:,0,:]
 det=a[:,0]*b[:,1]-a[:,1]*b[:,0]
 w1=(p[:,:,0]*b[:,1]-p[:,:,1]*b[:,0])/det
 w2=(a[None,:,0]*p[:,:,1]-a[None,:,1]*p[:,:,0])/det
 bary=np.stack((1-w1-w2,w1,w2),axis=2)
 inside=np.all(bary>=-1e-10,axis=2)&np.all(bary<=1+1e-10,axis=2)
 found=inside.any(1);selected=np.argmax(np.where(inside,bary.min(2),-np.inf),axis=1)
 hit=np.flatnonzero(found);newqids=4*parent[hit]+selected[hit]//4;fan=selected[hit]%4
 qq=qnew[newqids];pk=selected[hit]//4;of=qold[parent[hit]]
 if not np.array_equal(qq[:,1],of[np.arange(len(hit)),pk]) or not np.array_equal(qq[:,3],nv+ne+parent[hit]):
  raise ValueError('Sampled exact G7-to-G8 child lineage failed.')
 childtri=np.stack((xnew[qq[np.arange(len(hit)),fan]],xnew[qq[np.arange(len(hit)),(fan+1)%4]],xnew[qq].mean(1)),axis=1)
 weights=bary[hit,selected[hit]];xyz=np.einsum('ni,nij->nj',weights,childtri)
 result=dict(before_xyz=old['after_xyz'].copy(),after_xyz=np.full(shape+(3,),np.nan),mapped=np.zeros(shape,bool),
    triangle_ids=np.full(shape,-1,np.int64),barycentric=np.full(shape+(3,),np.nan),parent_G7_quad=np.full(shape,-1,np.int64))
 result['after_xyz'].reshape(-1,3)[where[hit]]=xyz;result['mapped'].ravel()[where[hit]]=True
 result['triangle_ids'].ravel()[where[hit]]=4*newqids+fan;result['barycentric'].reshape(-1,3)[where[hit]]=weights
 result['parent_G7_quad'].ravel()[where[hit]]=parent[hit]
 uv_error=float(np.max(np.abs(np.einsum('ni,nij->nj',weights,TRI[selected[hit]])-query[hit]),initial=0))
 return result,dict(valid_saved_G7_samples=int(valid.sum()),mapped_G8_samples=int(found.sum()),unmapped_G8_samples=int((~found).sum()),
    actual22_xyz_reconstruction_maximum_error=olderror,material_UV_reconstruction_maximum_error=uv_error,
    scope="Only four exact G8 children / sixteen native fans of the saved actual G7 parent quad.",world_nearest_used=False)
def main():
 started=time.perf_counter();output=HERE/'MACRO_FLOW_QA.json'
 if output.exists():raise FileExistsError('Existing whole CC1 macro QA preserved.')
 recovery_path=HERE/'RECOVERY_RECEIPT.json';recovery=read(recovery_path);prepare_path=HERE/'CC1_PREPARE_RECEIPT.json';prepare=read(prepare_path)
 if recovery['prepare_receipt_sha256']!=sha(prepare_path) or recovery['quality']['bad_quads']!=0:raise ValueError('Completed safe whole CC1 receipt required.')
 final=recovery['arrays']['RECOVERED_CC1_XYZ'];xnew=np.load(final['path'],mmap_mode='r')
 qrec=prepare['arrays']['CHILD_QUADS'];qnew=np.load(qrec['path'],mmap_mode='r')
 oldreceipt=read(OLD/'RECEIPT.json');oldcontrol=oldreceipt['variants']['MANDEL'];xold=mapped(oldcontrol['control_quad'],'xyz');qold=mapped(oldcontrol['control_quad'],'faces')
 nv=prepare['input_counts']['vertices'];ne=prepare['input_counts']['edges']
 if list(xnew.shape)!=final['shape'] or list(qnew.shape)!=qrec['shape'] or len(qnew)!=4*len(qold):raise ValueError('Final CC1 array count mismatch.')
 saved_path=OLD/'MACRO_FLOW_QA/EXACT_G7_PROFILE_SAMPLES.npz';preflight_path=oldqa.PREFLIGHT
 sources={str(Path(__file__)):sha(__file__),str(recovery_path):sha(recovery_path),str(prepare_path):sha(prepare_path),
    str(saved_path):sha(saved_path),str(OLD/'RECEIPT.json'):sha(OLD/'RECEIPT.json'),str(preflight_path):sha(preflight_path),
    str(QA/'qa_certified_macro_flow.py'):sha(QA/'qa_certified_macro_flow.py')}
 preflight=read(preflight_path);selected=[x for x in preflight['selected'] if x['component'] in (2,12,25,40)]
 records=[];components=[];sample_data={};measurement_bindings=[]
 with np.load(saved_path,allow_pickle=False) as archive:
  for item in selected:
   component=int(item['component']);prefix='component_%02d_'%component
   old={k:archive[prefix+k] for k in ('before_xyz','after_xyz','triangle_ids','barycentric','mapped')}
   samples,mapping=sample_component(old,xold,qold,xnew,qnew,nv,ne)
   m,binding=load_measurement(item['evidence']['description'],sources);measurement_bindings.append(binding)
   rows,_=oldqa.profile_metrics(component,m,samples)
   for row in rows:row['reference']='Completed22 actual G7 before whole CC1'
   if not rows:raise ValueError('No completed macro rows.')
   retention=np.array([row['prominence_retention'] for row in rows]);shift=np.array([row['absolute_peak_shift'] for row in rows])
   components.append(dict(component=component,measured_stations=len(rows),material_mapping=mapping,
     prominence_retention_quantiles=np.quantile(retention,[0,.1,.5,.9,1]).tolist(),
     absolute_peak_shift_quantiles=np.quantile(shift,[0,.5,.9,1]).tolist(),
     retention_below_90_percent=int(np.sum(retention<.9)),retention_above_110_percent=int(np.sum(retention>1.1)),
     peak_shift_over_075=int(np.sum(shift>.075))))
   records.extend(rows)
   sample_data.update({prefix+k:v for k,v in samples.items()})
   print('WHOLE_CC1_MACRO_COMPONENT',component,len(rows),mapping['unmapped_G8_samples'],flush=True)
 sample_path=HERE/'EXACT_G8_PROFILE_SAMPLES.npz';np.savez_compressed(sample_path,**sample_data)
 csv_path=HERE/'MACRO_FLOW_STATIONS.csv'
 with csv_path.open('x',encoding='utf-8',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
 retention=np.array([r['prominence_retention'] for r in records]);shift=np.array([r['absolute_peak_shift'] for r in records])
 result=dict(kind='COMPLETED22_G7_VS_WHOLE_CC1_G8_EXACT_MATERIAL_MACRO_FLOW_QA',sources=sources,
   original22_control=dict(path=oldcontrol['control_quad'],sha256=oldcontrol['control_quad_sha256']),
   final_coordinates=final,final_quads=qrec,components=components,sampled_stations=len(records),
   retention_quantiles=np.quantile(retention,[0,.1,.5,.9,1]).tolist(),absolute_peak_shift_quantiles=np.quantile(shift,[0,.5,.9,1]).tolist(),
   measurement_selected_array_bindings=measurement_bindings,
   sample_arrays=dict(path=str(sample_path),sha256=sha(sample_path)),stations=dict(path=str(csv_path),sha256=sha(csv_path)),
   filter=dict(FWHM=.075,analysis_only=True,geometry_smoothing=False),
   correspondence="Saved actual G7 fan barycentric→local parent UV→four exact CC children→sixteen child fan barycentric candidates. No world-nearest lookup.",
   geometry_changed=False,world_nearest_used=False,feature_birth_claimed=False,
   large_array_hash_policy="Use just-completed recovery/prepare bound full hashes and verify shapes; only selected coordinates are read. Saved actual22 sample XYZ is independently reconstructed.",
   limitations=["Four certified principal families, not every fold.","Native arithmetic-centre four-fan sampling; Blender quad display may choose a diagonal triangulation.","Review metrics only; prototype appearance is evaluated separately."],
   elapsed_seconds=time.perf_counter()-started)
 with output.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,ensure_ascii=False,allow_nan=False)
 print('WHOLE_CC1_MACRO_QA_COMPLETE',len(records),result['retention_quantiles'],result['absolute_peak_shift_quantiles'],time.perf_counter()-started,flush=True)
if __name__=='__main__':main()
