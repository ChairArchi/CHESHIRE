"""Streaming native-fan orientation recovery of one actual constrained whole CC1."""
from pathlib import Path
import sys,json,hashlib,time
sys.dont_write_bytecode=True
import numpy as np
ROOT=Path(r'E:\CHESHIRE_DATA\experiments\whole_cc1_prototype_20261016')
CHUNK=65536
MAX_PASSES=32

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 return h.hexdigest()
def ah(a):
 h=hashlib.sha256()
 for i in range(0,len(a),CHUNK):h.update(np.ascontiguousarray(a[i:i+CHUNK]).tobytes())
 return h.hexdigest()
def write(path,data):
 with Path(path).open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False)
def disk(name,shape,dtype,fill=None):
 p=ROOT/'working_arrays'/(name+'.npy')
 if p.exists():raise FileExistsError('Previous recovery array preserved: '+str(p))
 a=np.lib.format.open_memmap(p,mode='w+',dtype=dtype,shape=shape)
 if fill is not None:
  for i in range(0,len(a),CHUNK):a[i:i+CHUNK]=fill
 return a

def check(x,q,reference,bad):
 flips=degenerate=diagonal_flips=diagonal_baseline_degenerate=diagonal_degenerate=0;minimum_area=float('inf');minimum_dot=float('inf')
 for start in range(0,len(q),CHUNK):
  ids=q[start:start+CHUNK];p=x[ids];r=reference[ids];pc=p.mean(1);rc=r.mean(1)
  a=np.cross(p-pc[:,None],np.roll(p,-1,1)-pc[:,None]);b=np.cross(r-rc[:,None],np.roll(r,-1,1)-rc[:,None])
  dot=np.einsum('fki,fki->fk',a,b);area=.5*np.linalg.norm(a,axis=2)
  failed=(dot<=0)|~np.isfinite(dot)|(area<=0)|~np.isfinite(area)
  combined=failed.any(1)
  for triangles in (((0,1,2),(0,2,3)),((1,2,3),(1,3,0))):
   ti=np.asarray(triangles);pp=p[:,ti];rr=r[:,ti]
   aa=np.cross(pp[:,:,1]-pp[:,:,0],pp[:,:,2]-pp[:,:,0]);bb=np.cross(rr[:,:,1]-rr[:,:,0],rr[:,:,2]-rr[:,:,0])
   valid=np.einsum('fti,fti->ft',bb,bb)>0;dd=np.einsum('fti,fti->ft',aa,bb);alen=np.linalg.norm(aa,axis=2)
   df=valid&((dd<=0)|~np.isfinite(dd)|(alen<=0)|~np.isfinite(alen))
   diagonal_flips+=int(np.count_nonzero(valid&(dd<=0)));diagonal_degenerate+=int(np.count_nonzero(valid&(alen<=0)))
   diagonal_baseline_degenerate+=int(np.count_nonzero(~valid));combined|=df.any(1)
  bad[start:start+len(ids)]=combined
  flips+=int(np.count_nonzero(dot<=0));degenerate+=int(np.count_nonzero(area<=0))
  minimum_area=min(minimum_area,float(area.min()));minimum_dot=min(minimum_dot,float(dot.min()))
 return dict(reversed_quad_diagonal_triangles=diagonal_flips,degenerate_quad_diagonal_triangles=diagonal_degenerate,baseline_degenerate_diagonal_triangles_not_orientation_comparable=diagonal_baseline_degenerate,reversed_native_fans=flips,degenerate_native_fans=degenerate,minimum_native_fan_area=minimum_area,minimum_reference_cross_dot=minimum_dot,bad_quads=int(np.count_nonzero(bad)))

def main():
 started=time.perf_counter();path=ROOT/'CC1_PREPARE_RECEIPT.json'
 receipt=json.loads(path.read_text(encoding='utf-8'));sources={str(path):sha(path),str(Path(__file__).resolve()):sha(__file__)}
 def load(name):
  record=receipt['arrays'][name];p=Path(record['path'])
  if sha(p)!=record['sha256']:raise ValueError('Prepared source array changed: '+name)
  a=np.load(p,mmap_mode='r',allow_pickle=False)
  if list(a.shape)!=record['shape'] or str(a.dtype)!=record['dtype']:raise ValueError('Prepared array header changed: '+name)
  sources[str(p)]=record['sha256'];return a
 reference=load('BILINEAR_REFERENCE_XYZ');desired=load('DESIRED_CONSTRAINED_XYZ');q=load('CHILD_QUADS');pin=load('FLOW_PIN_WEIGHT')
 mx=load('MIRROR_X_VERTEX');my=load('MIRROR_Y_VERTEX')
 nv=len(reference);out=disk('RECOVERED_CC1_XYZ',reference.shape,np.float64);gain=disk('LOCAL_CC1_GAIN',(nv,),np.float64,1.)
 bad=disk('RECOVERY_BAD_QUADS',(len(q),),np.bool_,False);hit=disk('RECOVERY_HIT_VERTICES',(nv,),np.bool_,False);halo=disk('RECOVERY_HALO_VERTICES',(nv,),np.bool_,False)
 passes=[]
 for iteration in range(MAX_PASSES+1):
  finite=True;fixed_error=0.
  for start in range(0,nv,CHUNK):
   stop=min(start+CHUNK,nv);ref=np.asarray(reference[start:stop]);value=ref+(np.asarray(desired[start:stop])-ref)*gain[start:stop,None]
   fixed=pin[start:stop]>=1-1e-12;value[fixed]=ref[fixed];out[start:stop]=value
   finite &= bool(np.isfinite(value).all())
   if fixed.any():fixed_error=max(fixed_error,float(np.abs(value[fixed]-ref[fixed]).max()))
  if not finite:raise ValueError('Nonfinite candidate during recovery.')
  qa=check(out,q,reference,bad);qa.update(iteration=iteration,fixed_coordinate_max_error=fixed_error,elapsed_seconds=time.perf_counter()-started);passes.append(qa)
  print('WHOLE_CC1_ORIENTATION_PASS',json.dumps(qa),flush=True)
  if not qa['bad_quads']:break
  if iteration==MAX_PASSES:raise ValueError('Recovery limit reached; no whole model accepted.')
  hit[:]=False;halo[:]=False
  for start in range(0,len(q),CHUNK):
   block=q[start:start+CHUNK];b=bad[start:start+len(block)]
   if b.any():hit[block[b].ravel()]=True
  for start in range(0,len(q),CHUNK):
   block=q[start:start+CHUNK];selected=hit[block];neighbors=np.roll(selected,1,1)|np.roll(selected,-1,1)
   if neighbors.any():halo[block[neighbors]]=True
  for start in range(0,nv,CHUNK):
   stop=min(start+CHUNK,nv);g=np.asarray(gain[start:stop]).copy();hh=np.asarray(hit[start:stop]);ha=np.asarray(halo[start:stop])&~hh
   g[hh]*=.5;g[ha]*=.9;gain[start:stop]=g
  # Four-element X/Y reflection orbits: in-place group minima are order-independent.
  for start in range(0,nv,CHUNK):
   stop=min(start+CHUNK,nv);ix=np.asarray(mx[start:stop]);iy=np.asarray(my[start:stop]);ixy=mx[iy]
   gain[start:stop]=np.minimum.reduce([np.asarray(gain[start:stop]),gain[ix],gain[iy],gain[ixy]])
 out.flush();gain.flush();output={}
 for name,a in [('RECOVERED_CC1_XYZ',out),('LOCAL_CC1_GAIN',gain)]:
  p=ROOT/'working_arrays'/(name+'.npy');output[name]=dict(path=str(p),sha256=sha(p),array_sha256=ah(a),shape=list(a.shape),dtype=str(a.dtype))
 symmetry={}
 for label,mapping in [('X',mx),('Y',my)]:
  error=0.
  for start in range(0,nv,CHUNK):
   stop=min(start+CHUNK,nv);ref=np.asarray(out[mapping[start:stop]]).copy();ref[:,0 if label=='X' else 1]*=-1
   error=max(error,float(np.abs(ref-out[start:stop]).max()))
  symmetry[label]=error
 for p,h in sources.items():
  if sha(p)!=h:raise ValueError('Immutable prepared source changed: '+p)
 result=dict(kind='ACTUAL_WHOLE_CC1_CONSTRAINED_NATIVE_ORIENTATION_RECOVERY',prototype=True,original22_untouched=True,inputs=sources,prepare_receipt=str(path),prepare_receipt_sha256=sha(path),arrays=output,counts=dict(vertices=nv,quads=len(q),native_fan_triangles=4*len(q)),passes=passes,quality=passes[-1],symmetry_max_error=symmetry,rule='Only DESIRED minus BILINEAR_REFERENCE increment contracts by bad-quad .5 / quad-edge one-ring .9, then four-reflection-orbit minimum. Full flow pins retain exact bilinear22 target. No new Mandel/Tissue field is generated.',elapsed_seconds=time.perf_counter()-started)
 write(ROOT/'RECOVERY_RECEIPT.json',result);print('WHOLE_CC1_RECOVERY_COMPLETE',json.dumps(output),time.perf_counter()-started,flush=True)
if __name__=='__main__':main()