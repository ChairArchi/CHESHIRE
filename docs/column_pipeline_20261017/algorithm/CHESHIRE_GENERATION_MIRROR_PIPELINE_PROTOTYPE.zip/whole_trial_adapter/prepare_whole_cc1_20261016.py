"""Prepare whole constrained CC1 from immutable completed22; no extra ornament."""
from pathlib import Path
import sys,json,hashlib,zipfile,struct,time,shutil,gc
sys.dont_write_bytecode=True
import numpy as np
from whole_cc1_kernel import prepare_cc1,allocate,ranges
HERE=Path(__file__).resolve().parent
BASE=Path(r'E:\CHESHIRE_DATA\experiments\fold_aligned_mandel_20261015')
CURRENT=BASE/'variant22_flow_corrected_visible_relief_whole_hybrid_20261016'
EVIDENCE=Path(r'E:\CHESHIRE_DATA\experiments\end_rule_revision_20261014\trial01\replay\states\G07_SURFACE\evidence.npz')
CHUNK=65536
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def array_hash(a):
 h=hashlib.sha256()
 for start,stop in ranges(len(a),CHUNK):h.update(memoryview(np.ascontiguousarray(a[start:stop])).cast('B'))
 return h.hexdigest()
def write(name,data):
 p=HERE/name
 with p.open('x',encoding='utf-8') as f:json.dump(data,f,indent=2,ensure_ascii=False,allow_nan=False)
def mapped(path,key):
 p=Path(path)
 with zipfile.ZipFile(p) as z:
  i=z.getinfo(key+'.npy')
  if i.compress_type!=zipfile.ZIP_STORED:
   with np.load(p,allow_pickle=False) as data:return data[key]
  with p.open('rb') as f:
   f.seek(i.header_offset);h=f.read(30);nl,el=struct.unpack('<HH',h[26:30]);f.seek(nl+el,1)
   version=np.lib.format.read_magic(f)
   shape,order,dtype=np.lib.format.read_array_header_1_0(f) if version==(1,0) else np.lib.format.read_array_header_2_0(f)
   offset=f.tell()
 return np.memmap(p,mode='r',dtype=dtype,offset=offset,shape=shape,order='F' if order else 'C')
def smooth(x):
 x=np.clip(x,0,1);return x*x*x*(10+x*(-15+6*x))
def bind(record,sources):
 p=Path(record['path']);value=sha(p)
 if value!=record['sha256']:raise ValueError('Immutable source changed: '+str(p))
 sources[str(p)]=value;return np.load(p,mmap_mode='r',allow_pickle=False)
def mirror_arrays(arrays,nv,nf,source_x,source_y,source_fx,source_fy):
 root=HERE/'working_arrays';ne=len(arrays['INPUT_EDGES']);nout=nv+ne+nf
 edgekeys=arrays['INPUT_EDGE_KEYS'];edges=arrays['INPUT_EDGES'];result={}
 for label,vm,fm in [('X',source_x,source_fx),('Y',source_y,source_fy)]:
  if vm.shape!=(nv,) or fm.shape!=(nf,):raise ValueError('Original mirror topology count mismatch.')
  output=allocate(root,'MIRROR_'+label+'_VERTEX',(nout,),np.int64)
  for a,b in ranges(nv,CHUNK):output[a:b]=vm[a:b]
  for a,b in ranges(ne,CHUNK):
   transformed=vm[np.asarray(edges[a:b])];key=np.min(transformed,axis=1)*nv+np.max(transformed,axis=1)
   found=np.searchsorted(edgekeys,key)
   if np.any(found>=ne) or not np.array_equal(np.asarray(edgekeys[found]),key):raise ValueError('Reflected edge point absent.')
   output[nv+a:nv+b]=nv+found
  for a,b in ranges(nf,CHUNK):output[nv+ne+a:nv+ne+b]=nv+ne+fm[a:b]
  output.flush();arrays['MIRROR_'+label+'_VERTEX']=output;result[label]=output
 mx=result['X'];my=result['Y'];rep=allocate(root,'MIRROR_REPRESENTATIVE',(nout,),np.int64)
 for a,b in ranges(nout,CHUNK):
  ids=np.arange(a,b,dtype=np.int64);ix=np.asarray(mx[a:b]);iy=np.asarray(my[a:b]);ixy=np.asarray(mx[iy])
  if not np.array_equal(mx[ix],ids) or not np.array_equal(my[iy],ids) or not np.array_equal(ixy,my[ix]):raise ValueError('Lifted reflection orbit not exact.')
  rep[a:b]=np.minimum.reduce((ids,ix,iy,ixy))
 rep.flush();arrays['MIRROR_REPRESENTATIVE']=rep
 return mx,my
def main():
 started=time.perf_counter()
 if (HERE/'CC1_PREPARE_RECEIPT.json').exists() or (HERE/'working_arrays').exists():raise FileExistsError('Existing whole CC1 preparation preserved.')
 if shutil.disk_usage(HERE).free<9*1024**3:raise ValueError('Whole preparation requires at least9GiB free on E.')
 verification=HERE/'CC1_OPERATOR_VERIFICATION.json';v=json.loads(verification.read_text(encoding='utf-8'))
 if not v['passed'] or v['sources'][str(HERE/'whole_cc1_kernel.py')]!=sha(HERE/'whole_cc1_kernel.py'):
  raise ValueError('Frozen actual COMPAS kernel verification missing/changed.')
 receipt_path=CURRENT/'RECEIPT.json';r=json.loads(receipt_path.read_text(encoding='utf-8'));current=r['variants']['MANDEL'];cp=Path(current['control_quad'])
 sources={str(receipt_path):sha(receipt_path),str(verification):sha(verification)}
 if sha(cp)!=current['control_quad_sha256']:raise ValueError('Completed22 control mesh changed.')
 sources[str(cp)]=current['control_quad_sha256']
 srpath=BASE/'variant16_whole_hybrid_20261016/SOURCE_FIELD_RECEIPT.json';sr=json.loads(srpath.read_text(encoding='utf-8'));sources[str(srpath)]=sha(srpath)
 cls_path=CURRENT/'CLASSIFICATION.json';cls=json.loads(cls_path.read_text(encoding='utf-8'));sources[str(cls_path)]=sha(cls_path)
 if cls['display_flow_protection']!=r['formation']['classification']['display_flow_protection']:raise ValueError('Final22 pin display record is not generation-bound.')
 source_flow=bind(cls['display_flow_protection'],sources);shape=bind(sr['shape_vertex_fields'],sources);caps=bind(sr['protected_cap_mask'],sources);fine_weight=bind(sr['source_weights'],sources)
 if sha(EVIDENCE)!=sr['sources'][str(EVIDENCE)]:raise ValueError('Original G7 mirror lineage changed.')
 sources[str(EVIDENCE)]=sr['sources'][str(EVIDENCE)]
 x=mapped(cp,'xyz');q=mapped(cp,'faces');nv=len(x);nf=len(q)
 if (nv,nf)!=(7002114,7002112) or array_hash(q)!=sr['host_quad_faces_sha256']:raise ValueError('Expected exact completed22 original G7 quad topology.')
 if source_flow.shape!=(nv,) or shape.shape!=(nv,9) or caps.shape!=(nv,) or fine_weight.shape!=(nv,):raise ValueError('Control attribute binding mismatch.')
 pin=np.asarray(source_flow).copy()
 for a,b in ranges(nv,CHUNK):
  pin[a:b]=smooth(pin[a:b]);pin[a:b][pin[a:b]>=1-1e-12]=1.
 snapshots={}
 snap=HERE/'source_snapshot_prepare';snap.mkdir()
 for p in [Path(__file__),HERE/'whole_cc1_kernel.py',HERE/'verify_whole_cc1.py']:
  value=sha(p);shutil.copyfile(p,snap/p.name);snapshots[str(p)]=value
 write('CC1_INPUTS.json',dict(sources=sources,source_snapshots=snapshots,operator_verification=str(verification),
    original_current22_unchanged=True,whole_input=dict(vertices=nv,quads=nf),memory_budget_GiB=32,chunk=CHUNK))
 arrays,info=prepare_cc1(x,q,HERE/'working_arrays',float_attributes=dict(FLOW_PIN_WEIGHT=pin,SOURCE_SHAPE_WEIGHTS=shape[:,:5],SOURCE_FINE_WEIGHT=fine_weight),
   bool_attributes=dict(CAP_MASK=caps),chunk=CHUNK,allow_boundary=False)
 del pin;gc.collect()
 if info['input_counts']['edges']!=2*nf or info['input_Euler_characteristic']!=2 or info['output_Euler_characteristic']!=2:
  raise ValueError('Whole closed quad CC counts/Euler mismatch.')
 flow=arrays['FLOW_PIN_WEIGHT'];raw=arrays['RAW_CC_XYZ'];ref=arrays['BILINEAR_REFERENCE_XYZ'];nout=len(raw)
 desired=allocate(HERE/'working_arrays','DESIRED_CONSTRAINED_XYZ',(nout,3),np.float64)
 fullpin=0;actualmoving=0
 for a,b in ranges(nout,CHUNK):
  w=np.clip(np.asarray(flow[a:b]),0,1);w[w>=1-1e-12]=1.;flow[a:b]=w
  output=np.asarray(raw[a:b])*(1-w[:,None])+np.asarray(ref[a:b])*w[:,None];output[w==1]=ref[a:b][w==1]
  if not np.isfinite(output).all():raise ValueError('Nonfinite constrained CC.')
  desired[a:b]=output;fullpin+=int(np.sum(w==1));actualmoving+=int(np.sum(np.any(output!=ref[a:b],axis=1)))
 desired.flush();flow.flush();arrays['DESIRED_CONSTRAINED_XYZ']=desired
 mx,my=mirror_arrays(arrays,nv,nf,mapped(EVIDENCE,'mirror_x_vertex_pairs'),mapped(EVIDENCE,'mirror_y_vertex_pairs'),
    mapped(EVIDENCE,'mirror_x_face_pairs'),mapped(EVIDENCE,'mirror_y_face_pairs'))
 symmetry={}
 for name in ('RAW_CC_XYZ','BILINEAR_REFERENCE_XYZ','DESIRED_CONSTRAINED_XYZ'):
  target=arrays[name];maximum=0.
  for a,b in ranges(nout,CHUNK):
   value=np.asarray(target[a:b])
   for mirror,sign in [(mx,[-1.,1.,1.]),(my,[1.,-1.,1.])]:
    maximum=max(maximum,float(np.max(np.abs(value-np.asarray(target[np.asarray(mirror[a:b])])*sign))))
  if maximum>2e-12:raise ValueError('CC1 reflection symmetry failed.')
  symmetry[name]=maximum
 output_records={}
 for name,arr in arrays.items():
  p=Path(arr.filename);output_records[name]=dict(path=str(p),sha256=sha(p),shape=list(arr.shape),dtype=str(arr.dtype))
  print('CC1_ARRAY_HASH_BOUND',name,flush=True)
 stride=64;delta=np.linalg.norm(np.asarray(desired[::stride])-np.asarray(ref[::stride]),axis=1)
 maxweight=float(np.max(np.abs(np.asarray(arrays['SOURCE_SHAPE_WEIGHTS'][::stride]).sum(1)-1)))
 for p,h in snapshots.items():
  if sha(p)!=h:raise ValueError('Preparation source changed during run.')
 write('CC1_PREPARE_RECEIPT.json',dict(kind='WHOLE_COMPLETED22_TRUE_NEUTRAL_CC1_WITH_FLOW_CONSTRAINT',
    input_counts=info['input_counts'],output_counts=info['output_counts'],topology=info,arrays=output_records,
    sources=sources,source_snapshots=snapshots,operator_verification=dict(path=str(verification),sha256=sha(verification)),
    constraint=dict(reference='Exact bilinear refinement of completed22 original coordinates.',
     initial_pin='C2 quintic smooth of completed22 display protection; near1 snapped exact.',
     transport='V original pin; E endpoint mean; F corner mean; near1 snapped exact.',
     full_pin_controls=fullpin,full_pin_reference_coordinates_exact=True,caps_are_display_only_not_extra_geometry_pin=True,
     actual_moved_vs_bilinear_reference_controls=actualmoving,new_Mandel_reinjection=False),
    symmetry_maximum_error=symmetry,shape_weight_sample_maximum_normalization_error=maxweight,
    displacement_sample=dict(stride=stride,quantile_positions=[0,.5,.9,.99,1],desired_vs_bilinear=np.quantile(delta,[0,.5,.9,.99,1]).tolist()),
    final_native_orientation_recovery_pending=True,
    final_output_contract=dict(coordinates='RECOVERED_CC1_XYZ.npy',gain='LOCAL_CC1_GAIN.npy',receipt='RECOVERY_RECEIPT.json'),
    original_current22_preserved=True,elapsed_seconds=time.perf_counter()-started))
 print('WHOLE_CC1_PREPARE_COMPLETE',time.perf_counter()-started,flush=True)
if __name__=='__main__':main()
