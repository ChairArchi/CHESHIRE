﻿"""Reusable actual recursive plane cut/mirror/Boolean-union geometry kernel."""
import numpy as np
import manifold3d as manifold
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components


def arrays(solid):
    mesh=solid.to_mesh64()
    return np.array(mesh.vert_properties[:,:3],dtype=np.float64,copy=True),np.array(mesh.tri_verts,dtype=np.int64,copy=True)


def solid_from_arrays(x,tri):
    result=manifold.Manifold(manifold.Mesh64(np.ascontiguousarray(x,np.float64),np.ascontiguousarray(tri,np.uint64)))
    if str(result.status())!='Error.NoError' or result.is_empty():raise ValueError('Input is not a valid nonempty oriented solid: '+str(result.status()))
    return result


def mesh_quality(x,faces):
    q=np.asarray(faces,np.int64);edges=np.sort(np.stack([q,np.roll(q,-1,axis=1)],axis=-1).reshape(-1,2),axis=1)
    unique,counts=np.unique(edges,axis=0,return_counts=True)
    graph=coo_matrix((np.ones(len(unique)),(unique[:,0],unique[:,1])),shape=(len(x),len(x)))
    components,_=connected_components(graph,directed=False)
    p=x[q];center=p.mean(axis=1);cross=np.cross(p-center[:,None],np.roll(p,-1,axis=1)-center[:,None]);area=np.linalg.norm(cross,axis=2)/2
    chi=len(x)-len(unique)+len(q)
    return dict(vertices=len(x),faces=len(q),edges=len(unique),face_corners=q.shape[1],components=int(components),
        boundary_edges=int(np.count_nonzero(counts==1)),nonmanifold_edges=int(np.count_nonzero(counts>2)),
        euler_characteristic=int(chi),genus_if_closed_connected=(2-chi)//2 if components==1 and np.all(counts==2) else None,
        finite=bool(np.isfinite(x).all()),degenerate_fans=int(np.count_nonzero(area<=1e-18)),minimum_fan_area=float(area.min()),
        bbox=[x.min(0).tolist(),x.max(0).tolist()])


def largest_area(solid):
    parts=solid.decompose()
    if not parts:raise ValueError('No connected solid remains.')
    areas=[float(p.surface_area()) for p in parts];i=int(np.argmax(areas))
    return parts[i],dict(components_before_selection=len(parts),component_surface_areas=areas,selected_component=i,
                        criterion='largest surface area, as in paper')


def recursive_mirror(x,tri,planes,*,maximum_triangles=32000,callback=None):
    current,selection=largest_area(solid_from_arrays(x,tri));records=[]
    for number,config in enumerate(planes):
        before_x,before_f=arrays(current);normal=np.asarray(config['normal'],float);normal/=np.linalg.norm(normal)
        offset=float(config['offset']);signed=before_x@normal-offset
        adjusted=False
        if signed.min()>=-1e-8 or signed.max()<=1e-8:
            offset=float(np.median(before_x@normal));signed=before_x@normal-offset;adjusted=True
        if not signed.min()<0<signed.max():raise ValueError('Plane must cut the currently largest connected solid.')
        edges=np.unique(np.sort(np.stack([before_f,np.roll(before_f,-1,axis=1)],axis=-1).reshape(-1,2),axis=1),axis=0)
        crossing=int(np.count_nonzero(signed[edges[:,0]]*signed[edges[:,1]]<0))
        half=current.trim_by_plane(normal.tolist(),offset)
        if half.is_empty() or str(half.status())!='Error.NoError':raise ValueError('Actual halfspace trim failed.')
        hx,hf=arrays(half)
        if np.min(hx@normal-offset)<-1e-8:raise ValueError('Discarded negative halfspace survived actual clipping.')
        reflection=half.translate((-offset*normal).tolist()).mirror(normal.tolist()).translate((offset*normal).tolist())
        rx,rf=arrays(reflection);expected=hx-2*(hx@normal-offset)[:,None]*normal
        reflection_error=float(np.max(np.abs(expected-rx))) if expected.shape==rx.shape else float('inf')
        if reflection_error>1e-10:
            a=expected[np.lexsort(expected.T[::-1])];b=rx[np.lexsort(rx.T[::-1])]
            reflection_error=float(np.max(np.abs(a-b))) if a.shape==b.shape else float('inf')
        if reflection_error>1e-9:raise ValueError('Actual reflection differs from plane equation.')
        joined=half+reflection
        if joined.is_empty() or str(joined.status())!='Error.NoError':raise ValueError('Actual Boolean union failed.')
        union_volume=float(joined.volume());half_volume=float(half.volume())
        volume_error=abs(union_volume-2*half_volume)
        if volume_error>1e-8*max(1.,abs(union_volume)):raise ValueError('Cut-reflect union volume is inconsistent.')
        current,selected=largest_area(joined);ux,uf=arrays(current);qa=mesh_quality(ux,uf)
        if len(uf)>maximum_triangles:raise ValueError('Bounded paper operator face budget exceeded.')
        if qa['components']!=1 or qa['boundary_edges'] or qa['nonmanifold_edges'] or not qa['finite']:raise ValueError('Paper union is not one closed two-manifold.')
        seam=np.abs(ux@normal-offset)<1e-8
        record=dict(iteration=number+1,requested_plane=config,normal=normal.tolist(),actual_offset=offset,plane_adjusted_to_intersect_largest=adjusted,
            input_vertices=len(before_x),input_triangles=len(before_f),discarded_negative_vertices=int(np.count_nonzero(signed<0)),
            crossed_input_edges=crossing,cut_vertices=len(hx),cut_triangles=len(hf),reflected_vertices=len(rx),
            reflection_coordinate_max_error=reflection_error,Boolean_union_API='manifold3d.Manifold.__add__',
            exact_operator='trim_by_plane(positive halfspace) -> reflect across actual plane -> Boolean union -> largest connected surface area',
            union_volume=union_volume,half_volume=half_volume,union_double_half_volume_error=volume_error,
            output_seam_vertices=int(seam.sum()),largest_component=selected,quality=qa)
        records.append(record)
        if callback:callback(number+1,(hx,hf),(rx,rf),(ux,uf),record)
    ox,of=arrays(current)
    return ox,of,dict(initial_largest_component=selection,iterations=records,final_quality=mesh_quality(ox,of),
                     cut_discard_reflect_Boolean_union_actual=True,largest_component_by_area=True,
                     plane_order_is_material=True,manifold_status=str(current.status()))
