"""Reusable authored-history classification; no paths, feature seeds or face IDs."""
from dataclasses import dataclass,asdict
import heapq
import numpy as np

@dataclass(frozen=True)
class HistoryConfig:
    radius: float
    length_scale: float
    minimum_samples: int = 8
    minimum_G2_ancestor_faces: int = 3
    maximum_gradient_condition: float = 20.
    prior_mix: float = .70
    early_turn_start: float = .01
    early_turn_full: float = .12
    middle_amplitude_start_fraction: float = .0005
    middle_amplitude_full_fraction: float = .0025
    late_amplitude_start_fraction: float = .00008
    late_amplitude_full_fraction: float = .0006
    tissue_history_threshold: float = .52

def smooth(x):
    x=np.clip(x,0.,1.);return x*x*x*(10+x*(-15+6*x))
def unit(x):return x/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1e-30)
def ball(graph,seed,radius):
    d={int(seed):0.};queue=[(0.,int(seed))]
    while queue:
        distance,i=heapq.heappop(queue)
        if d[i]!=distance:continue
        for j,w in zip(graph.indices[graph.indptr[i]:graph.indptr[i+1]],graph.data[graph.indptr[i]:graph.indptr[i+1]]):
            j=int(j);nd=distance+float(w)
            if nd<=radius and nd<d.get(j,float('inf')):d[j]=nd;heapq.heappush(queue,(nd,j))
    return np.fromiter(d,np.int64),np.fromiter(d.values(),float)
def neutral_retained_predictions(xyz,quads,anchors,chunk=65536):
    """Actual neutral-CC retained-V rule at requested IDs, closed input only."""
    anchors=np.asarray(anchors,np.int64);lo=int(anchors.min());hi=int(anchors.max())+1
    if not np.array_equal(anchors,np.arange(lo,hi)):raise ValueError('Adapter requires consecutive exact retained anchors.')
    n=len(anchors);fs=np.zeros((n,3));ms=np.zeros((n,3));normal=np.zeros((n,3));count=np.zeros(n,np.int32)
    for start in range(0,len(quads),chunk):
        q=np.asarray(quads[start:start+chunk]);hit=(q>=lo)&(q<hi);selected=hit.any(1)
        if not np.any(selected):continue
        q=q[selected];hit=hit[selected];p=np.asarray(xyz[q]);f=p.mean(1)
        fn=unit(np.cross(p-f[:,None,:],np.roll(p,-1,axis=1)-f[:,None,:]).sum(1))
        for k in range(4):
            choose=hit[:,k];ids=q[choose,k]-lo
            np.add.at(fs,ids,f[choose]);np.add.at(count,ids,1);np.add.at(normal,ids,fn[choose])
            mid1=.5*(p[choose,k]+p[choose,(k-1)%4]);mid2=.5*(p[choose,k]+p[choose,(k+1)%4])
            np.add.at(ms,ids,.5*(mid1+mid2))
    if np.any(count<3):raise ValueError('Expected closed retained-anchor incidence.')
    old=np.asarray(xyz[anchors]);degree=count[:,None]
    predicted=(fs/degree+2*ms/degree+(degree-3)*old)/degree
    return predicted,unit(normal),count

def scalar_gradient(xyz,normals,graph,values,max_condition):
    n=len(xyz);gradient=np.zeros((n,3));condition=np.full(n,np.inf);valid=np.zeros(n,bool)
    for i in range(n):
        a,b=graph.indptr[i:i+2];ids=graph.indices[a:b]
        nrm=normals[i];e=np.array([0.,0.,1.])-nrm*nrm[2]
        if np.linalg.norm(e)<.1:e=np.array([1.,0.,0.])-nrm*nrm[0]
        e=unit(e);frame=np.column_stack((e,np.cross(nrm,e)))
        dp=(xyz[ids]-xyz[i])@frame;dh=values[ids]-values[i]
        if len(ids)<2 or not np.isfinite(dp).all() or not np.isfinite(dh).all():continue
        condition[i]=np.linalg.cond(dp)
        if condition[i]>max_condition or np.linalg.matrix_rank(dp)<2:continue
        gradient[i]=frame@np.linalg.lstsq(dp,dh,rcond=None)[0];valid[i]=True
    return gradient,condition,valid

def _direction_tensor(vectors,weights):
    if not len(vectors) or weights.sum()<=1e-30:return 0.,np.zeros(3),0.
    tensor=np.einsum('n,ni,nj->ij',weights,vectors,vectors)/weights.sum()
    eig,axis=np.linalg.eigh(tensor);coherence=(eig[2]-eig[1])/max(eig[2]+eig[1],1e-30)
    return float(np.clip(coherence,0,1)),axis[:,2],float(eig.sum())

def history_features(reference_centres,reference_normals,early_normals,G2_parent_faces,
                     graph,reference_area,middle_delta,late_delta,other_authored_deltas,config,progress=None):
    """Observed normal-turning persistence plus actual authored displacement RMS.

    early_normals=(4,N,3): actual G2/G3/G4/G5 at identical material anchors.
    This is a distribution statistic, not failed normal-curvature least squares.
    G2 independent parent coverage is checked separately from sample count.
    """
    nf=len(reference_centres);normal=unit(reference_normals)
    signed_middle=np.einsum('ni,ni->n',middle_delta,normal)
    signed_late=np.einsum('ni,ni->n',late_delta,normal)
    gm,cm,vm=scalar_gradient(reference_centres,normal,graph,signed_middle,config.maximum_gradient_condition)
    gl,cl,vl=scalar_gradient(reference_centres,normal,graph,signed_late,config.maximum_gradient_condition)
    names=['middle_RMS','late_RMS','other_authored_RMS','middle_gradient_coherence','late_gradient_coherence',
       'early_normal_turn','early_one_axis','early_axis_alignment','early_confidence','history_confidence',
       'reference_neighbors','unique_G2_ancestor_faces','middle_gradient_valid_fraction','late_gradient_valid_fraction']
    out={name:np.zeros(nf,float) for name in names}
    out['early_stage_normal_turn']=np.full((4,nf),np.nan)
    out['early_stage_one_axis']=np.full((4,nf),np.nan)
    out['early_stage_axis']=np.full((4,nf,3),np.nan)
    out['middle_gradient_condition']=cm;out['late_gradient_condition']=cl
    out['middle_gradient']=gm;out['late_gradient']=gl
    m2=np.sum(middle_delta**2,1);l2=np.sum(late_delta**2,1)
    o2=np.sum(np.asarray(other_authored_deltas)**2,axis=(0,2)) if len(other_authored_deltas) else np.zeros(nf)
    for i in range(nf):
        ids,dist=ball(graph,i,config.radius);w=(1-(dist/config.radius)**2)**2*reference_area[ids]
        sw=max(w.sum(),1e-30);out['reference_neighbors'][i]=len(ids)
        out['middle_RMS'][i]=np.sqrt(np.sum(w*m2[ids])/sw)
        out['late_RMS'][i]=np.sqrt(np.sum(w*l2[ids])/sw)
        out['other_authored_RMS'][i]=np.sqrt(np.sum(w*o2[ids])/sw)
        out['middle_gradient_valid_fraction'][i]=np.sum(w*vm[ids])/sw
        out['late_gradient_valid_fraction'][i]=np.sum(w*vl[ids])/sw
        out['middle_gradient_coherence'][i]=_direction_tensor(gm[ids],w*vm[ids])[0]
        out['late_gradient_coherence'][i]=_direction_tensor(gl[ids],w*vl[ids])[0]
        unique=G2_parent_faces[ids];unique=unique[unique>=0];out['unique_G2_ancestor_faces'][i]=len(np.unique(unique))
        stage_valid=[]
        for stage in range(4):
            vectors=early_normals[stage,ids];finite=np.isfinite(vectors).all(1);stage_valid.append(int(finite.sum()))
            if finite.sum()<config.minimum_samples:continue
            ww=w[finite];v=unit(vectors[finite]);M=np.einsum('n,ni,nj->ij',ww,v,v)/max(ww.sum(),1e-30)
            eig,axis=np.linalg.eigh(M)
            out['early_stage_normal_turn'][stage,i]=np.clip(1-eig[2],0,1)
            out['early_stage_one_axis'][stage,i]=np.clip((eig[1]-eig[0])/max(eig[1]+eig[0],1e-30),0,1)
            out['early_stage_axis'][stage,i]=axis[:,0]
        early_ok=min(stage_valid)>=config.minimum_samples and out['unique_G2_ancestor_faces'][i]>=config.minimum_G2_ancestor_faces
        if early_ok:
            out['early_normal_turn'][i]=float(np.median(out['early_stage_normal_turn'][:,i]))
            out['early_one_axis'][i]=float(np.median(out['early_stage_one_axis'][:,i]))
            axes=out['early_stage_axis'][:,i];align=np.abs(axes@axes[1])
            out['early_axis_alignment'][i]=float(align.min())
            out['early_confidence'][i]=min(1.,min(stage_valid)/16.)*min(1.,out['unique_G2_ancestor_faces'][i]/6.)
        if len(ids)>=config.minimum_samples:
            out['history_confidence'][i]=min(1.,len(ids)/16.)*(.5+.5*min(out['middle_gradient_valid_fraction'][i],out['late_gradient_valid_fraction'][i]))
        if progress is not None and i%5000==0:progress(i,nf)
    return out

def reweight_history_classes(prior,features,config,*,use_early=True):
    """Prior updated by evidence; five classes retain existing display semantics."""
    p=np.asarray(prior,float);p=p/np.maximum(p.sum(1,keepdims=True),1e-30)
    f=features;H=config.length_scale
    middle=smooth((f['middle_RMS']/H-config.middle_amplitude_start_fraction)/(config.middle_amplitude_full_fraction-config.middle_amplitude_start_fraction))
    late=smooth((f['late_RMS']/H-config.late_amplitude_start_fraction)/(config.late_amplitude_full_fraction-config.late_amplitude_start_fraction))
    total=f['middle_RMS']+f['late_RMS']+f['other_authored_RMS']+1e-30
    middle_share=f['middle_RMS']/total;late_share=f['late_RMS']/total
    ec=f['early_confidence'] if use_early else np.zeros(len(p))
    presence=smooth((f['early_normal_turn']-config.early_turn_start)/(config.early_turn_full-config.early_turn_start))*ec
    oneaxis=f['early_one_axis']*smooth((f['early_axis_alignment']-.65)/.30)*presence
    cm=smooth((f['middle_gradient_coherence']-.35)/.50);cl=smooth((f['late_gradient_coherence']-.35)/.50)
    persistent=middle*middle_share*(.35*cm+.65*oneaxis)
    late_complex=late*(.35+.65*smooth((late_share-.12)/.40))*(1-.55*oneaxis)*(1-.65*cl)
    early_multidir=presence*(1-f['early_one_axis'])*(.25+.75*late)
    complex_score=np.clip(late_complex+.45*early_multidir,0,1)
    calm=p[:,0]*(1-presence)*(1-late)*(.5+.5*(1-middle))
    strong=persistent*(1-.65*complex_score)
    weak=.10+.30*(1-np.maximum(persistent,complex_score))
    fraction=np.divide(p[:,3],p[:,3]+p[:,4],out=np.full(len(p),.35),where=(p[:,3]+p[:,4])>1e-12)
    target=np.column_stack((calm,weak,strong,complex_score*fraction,complex_score*(1-fraction)))
    target/=np.maximum(target.sum(1,keepdims=True),1e-30)
    alpha=config.prior_mix*f['history_confidence']
    result=(1-alpha[:,None])*p+alpha[:,None]*target;result/=result.sum(1,keepdims=True)
    return result,dict(persistent_fold_evidence=persistent,late_complexity_evidence=complex_score,
        early_presence=presence,early_one_axis_persistence=oneaxis,late_share=late_share,
        history_mix_alpha=alpha)

def select_tissue_hosts(weights,evidence,events,source_caps,graph,config):
    actual=np.asarray(events)>0;caps=np.asarray(source_caps,bool);source=(~actual)&(~caps)
    interface=np.zeros(len(actual),bool)
    for i in np.flatnonzero(source):
        a,b=graph.indptr[i:i+2];interface[i]=bool(np.any(actual[graph.indices[a:b]]))
    complex_mass=weights[:,3]+weights[:,4]
    score=np.clip(.65*evidence['late_complexity_evidence']+.35*complex_mass,0,1)
    new_source=source&(score>=config.tissue_history_threshold)&(evidence['history_mix_alpha']>=.35)
    selected=(actual|interface|new_source)&~caps
    priority=np.zeros(len(selected));priority[actual]=1.;priority[interface]=1.
    priority[new_source]=smooth((score[new_source]-.35)/.45)
    reason=np.zeros(len(selected),np.int8);reason[actual]=1;reason[interface]=2;reason[new_source]=3
    return selected,priority,reason,score

def contract(config):
    return dict(config=asdict(config),class_names=['calm','weak_fold','strong_coherent_fold','rounded_bulge','multidirectional_junction_candidate'],
      early_evidence="Actual G2/G3/G4/G5 normal-turning distribution and sign-free one-axis persistence in one fixed physical/material window; not curvature fitting.",
      residual_semantics="Actual-minus-neutral-predicted vertex placement and fields, not pure fold delta.",
      history_units="All coordinates/radius/length_scale share model units; amplitude thresholds are fractions of one global declared length scale.",
      feature_birth_claimed=False,topological_vertex_birth_is_not_feature_birth=True,
      correspondence_required=True,insufficient_history_fallback="Keep prior; never infer pre-event absence from an undefined counterpart.",
      junction_semantics="Multidirectional shape candidate, not certified topological branching.",
      flow_priority="Final actual G7 ridge and weak-profile scalar guards preserve principal corridors independently of class/host admission.")
