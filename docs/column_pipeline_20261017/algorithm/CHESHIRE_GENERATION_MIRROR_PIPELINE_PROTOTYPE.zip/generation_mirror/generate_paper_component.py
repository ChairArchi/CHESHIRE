﻿"""Finite Mandel seed -> actual recursive paper operations -> actual project CC1."""
from pathlib import Path
import sys,os,json,hashlib,importlib.util,time,shutil
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'component'
VENDOR=Path(r'C:\Users\USER\CHESHIRE\scratch\grotesque_gate_20261010\deps')
os.add_dll_directory(str(VENDOR));sys.path.insert(0,str(VENDOR));sys.path.insert(0,str(ROOT))
PROJECT=Path(r'C:\Users\USER\CHESHIRE\worktrees\connected-fold-growth-20261012')
sys.path.insert(0,str(PROJECT/'src'))
import numpy as np
from skimage.measure import marching_cubes
from compas.datastructures import Mesh
from cheshire.surface import catmull_clark_once
from cheshire.execution import ExecutionBudget
from paper_component_kernel import recursive_mirror,mesh_quality
SOURCE=PROJECT/'experiments/fold_junction_development_20261015/parent_local_mandelbulb.py'
spec=importlib.util.spec_from_file_location('actual_finite_mandel_membership',SOURCE);source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,data):Path(path).write_text(json.dumps(data,ensure_ascii=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def save(name,x,f):
 p=OUT/(name+'.npz');np.savez(p,xyz=x,faces=f)
 return dict(path=str(p),sha256=sha(p),quality=mesh_quality(x,f))
started=time.perf_counter()
if OUT.exists():raise FileExistsError('Preserve prior paper component.')
OUT.mkdir();(OUT/'source_snapshot').mkdir()
for p in (Path(__file__).resolve(),ROOT/'paper_component_kernel.py',SOURCE,PROJECT/'src/cheshire/surface.py'):
 shutil.copyfile(p,OUT/'source_snapshot'/p.name)
axis=np.linspace(-1.35,1.35,56);grid=np.stack(np.meshgrid(axis,axis,axis,indexing='ij'),axis=-1)
inside=source.membership(grid.reshape(-1,3),power=8,iterations=8).reshape(56,56,56)
if np.any(inside[[0,-1]]) or np.any(inside[:,[0,-1]]) or np.any(inside[:,:,[0,-1]]):raise ValueError('Finite volume touches extraction box.')
x,f,_,_=marching_cubes(inside.astype(np.float32),level=.5,spacing=(axis[1]-axis[0],)*3,allow_degenerate=False,method='lewiner')
x=x.astype(np.float64)+axis[0];f=f.astype(np.int64)
volume=np.einsum('ij,ij->i',x[f[:,0]],np.cross(x[f[:,1]],x[f[:,2]])).sum()/6
if volume<0:f=f[:,[0,2,1]]
seed=save('00_finite_Mandel_seed',x,f)
print('ACTUAL_FINITE_MANDEL_SEED',len(x),len(f),seed['quality'],flush=True)
planes=[dict(normal=[1.,.18,.12],offset=.05),dict(normal=[.23,1.,.18],offset=.10),
        dict(normal=[.15,.26,1.],offset=.15),dict(normal=[.82,.62,-.22],offset=.20)]
stages=[]
def callback(i,half,reflection,joined,record):
 data=dict(half=save('%02d_cut_positive'%i,*half),reflected=save('%02d_reflected'%i,*reflection),union=save('%02d_union_largest'%i,*joined),operator=record)
 stages.append(data);write(OUT/('%02d_OPERATOR_RECEIPT.json'%i),data)
 print('ACTUAL_CUT_REFLECT_UNION',i,len(joined[0]),len(joined[1]),record['quality']['genus_if_closed_connected'],flush=True)
ux,uf,operator=recursive_mirror(x,f,planes,maximum_triangles=32000,callback=callback)
pre=save('05_paper_pre_CC',ux,uf)
mesh=Mesh.from_vertices_and_faces(ux.tolist(),uf.tolist())
cc=catmull_clark_once(mesh,budget=ExecutionBudget(110000,110000))
keys=list(cc.mesh.vertices());rows={k:i for i,k in enumerate(keys)}
cx=np.array([cc.mesh.vertex_coordinates(k) for k in keys],np.float64)
cq=np.array([[rows[k] for k in cc.mesh.face_vertices(key)] for key in cc.mesh.faces()],np.int64)
final=save('06_actual_paper_CC1_component',cx,cq)
if final['quality']['boundary_edges'] or final['quality']['nonmanifold_edges'] or final['quality']['components']!=1 or final['quality']['degenerate_fans']:
 raise ValueError('Actual paper CC1 component quality failed.')
geometry=OUT/'ACTUAL_PAPER_COMPONENT.json'
write(geometry,dict(vertices=cx.tolist(),faces=cq.tolist(),operator='Actual finite Mandel volume -> 4 recursive plane cut/reflection/Boolean unions -> largest-area component -> project COMPAS Catmull-Clark1',
                   closed_3D_component=True,original_column_modified=False))
receipt=dict(kind='ACTUAL_PAPER_RECURSIVE_SYMMETRY_FINITE_MANDEL_COMPONENT',actual_operator_succeeded=True,
 paper=dict(path=r'C:\Users\USER\Downloads\mirror.pdf',sha256=sha(r'C:\Users\USER\Downloads\mirror.pdf'),doi='10.1016/j.cad.2016.09.002',section='2.1',figure='3; plane traversal order influences outcome'),
 seed=seed,finite_Mandel=dict(power=8,iterations=8,bailout_radius=2.,grid_resolution=[56]*3,bounds=[-1.35,1.35],membership_source=str(SOURCE),membership_source_sha256=sha(SOURCE),finite_volume_is_approximation=True),
 stages=stages,paper_operator=operator,pre_CC=pre,actual_CC1=cc.metadata,final=final,
 component_geometry=str(geometry),component_geometry_sha256=sha(geometry),
 actual_closed_3D_geometry_retained=True,whole_column_not_yet_assembled=True,original_column_modified=False,
 no_post_CC_profile_filter=True,elapsed_seconds=time.perf_counter()-started,
 sources={str(p):sha(p) for p in (Path(__file__).resolve(),ROOT/'paper_component_kernel.py',PROJECT/'src/cheshire/surface.py')})
write(OUT/'PAPER_COMPONENT_RECEIPT.json',receipt)
print('PAPER_COMPONENT_ACTUAL_SUCCESS',len(cx),len(cq),final['quality'],time.perf_counter()-started,flush=True)
