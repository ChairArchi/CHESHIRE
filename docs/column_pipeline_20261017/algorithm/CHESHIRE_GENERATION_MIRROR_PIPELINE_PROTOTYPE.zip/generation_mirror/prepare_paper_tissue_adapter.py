﻿"""Exact top-ray paper surface adapter -> one actual upstream Tissue QUAD/LAST call.
The closed 3D paper mesh is retained separately. A topmost ray graph cannot
transfer its overhangs or handles; this limitation is recorded explicitly.
"""
from pathlib import Path
import sys,os,json,hashlib,shutil,subprocess,time
sys.dont_write_bytecode=True
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'paper_tissue'
PAPER=ROOT/'component'
OLD=Path(r'E:\CHESHIRE_DATA\experiments\whole_tissue_relief_20261016')
EXTERNAL=Path(r'C:\Users\USER\CHESHIRE\scratch\generative_gate_20261010\external')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,data):Path(p).write_text(json.dumps(data,ensure_ascii=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')
started=time.perf_counter()
if OUT.exists():raise FileExistsError('Preserve any prior paper Tissue adapter.')
OUT.mkdir();(OUT/'source_snapshot').mkdir()
source=PAPER/'06_actual_paper_CC1_component.npz';source_sha=sha(source)
with np.load(source,allow_pickle=False) as d:x=d['xyz'];q=d['faces']
xx=np.concatenate([x,x[q].mean(1)]);tri=np.empty((len(q),4,3),np.int64)
tri[:,:,0]=q;tri[:,:,1]=np.roll(q,-1,axis=1);tri[:,:,2]=(len(x)+np.arange(len(q)))[:,None]
tri=tri.reshape(-1,3);p=xx[tri];v0=p[:,0];e1=p[:,1]-v0;e2=p[:,2]-v0
normal=np.cross(e1,e2);normal/=np.linalg.norm(normal,axis=1)[:,None]
lo=p[:,:,:2].min(1);hi=p[:,:,:2].max(1);den=e1[:,0]*e2[:,1]-e1[:,1]*e2[:,0]
axes=[np.linspace(x[:,k].min(),x[:,k].max(),33) for k in (0,1)]
height=np.zeros((33,33));points=np.zeros((33,33,3));normals=np.zeros((33,33,3));face=np.full((33,33),-1,np.int64);bary=np.zeros((33,33,3));layers=np.zeros((33,33),np.int32)
for j,y in enumerate(axes[1]):
 for i,a in enumerate(axes[0]):
  ids=np.flatnonzero((lo[:,0]<=a+1e-12)&(hi[:,0]>=a-1e-12)&(lo[:,1]<=y+1e-12)&(hi[:,1]>=y-1e-12)&(np.abs(den)>1e-16))
  if not len(ids):continue
  dx=a-v0[ids,0];dy=y-v0[ids,1]
  s=(dx*e2[ids,1]-dy*e2[ids,0])/den[ids];t=(e1[ids,0]*dy-e1[ids,1]*dx)/den[ids]
  valid=(s>=-1e-9)&(t>=-1e-9)&(s+t<=1+1e-9)
  ids=ids[valid];s=s[valid];t=t[valid]
  if not len(ids):continue
  z=v0[ids,2]+s*e1[ids,2]+t*e2[ids,2];k=int(np.argmax(z));fid=int(ids[k]);b=np.array([1-s[k]-t[k],s[k],t[k]])
  points[j,i]=b@p[fid];normals[j,i]=normal[fid];face[j,i]=fid;bary[j,i]=b;layers[j,i]=len(np.unique(np.round(z,10)));height[j,i]=z[k]
hit=face>=0
if np.count_nonzero(hit)<200:raise ValueError('Paper component has insufficient actual projected surface support.')
low=float(x[:,2].min());high=float(x[:,2].max());profile=np.zeros((33,33));profile[hit]=np.clip((height[hit]-low)/(high-low),0,1)
u,v=np.meshgrid(np.linspace(0,1,33),np.linspace(0,1,33))
envelope=np.maximum(1-(2*u-1)**6,0)**3*np.maximum(1-(2*v-1)**4,0)**3
# Twelve percent filled inflation keeps through-hole projections as shallow
# depressions; eighty-eight percent carries the new actual paper surface.
z=.055*envelope*(.12+.88*profile);ports=(u==0)|(u==1)|(v==0)|(v==1);z[ports]=0.
component_xyz=np.stack([u,v,z],axis=-1).reshape(-1,3)
component_faces=np.array([[j*33+i,j*33+i+1,(j+1)*33+i+1,(j+1)*33+i] for j in range(32) for i in range(32)],np.int64)
tangent=normals[:,:,:2].copy();length=np.linalg.norm(tangent,axis=2);tangent=np.divide(tangent,length[:,:,None],out=np.zeros_like(tangent),where=length[:,:,None]>1e-12)
np.savez(OUT/'PAPER_EXACT_TOP_RAY_ADAPTER.npz',raw_normalized_profile=profile,actual_surface_points=points,actual_triangle_ids=face,
 barycentric=bary,actual_surface_normals=normals,actual_normal_xy_direction=tangent,unique_ray_height_layers=layers,
 hit_mask=hit,uv=np.linspace(0,1,33),component_height=z)
component=OUT/'paper_derived_component.json'
write(component,dict(vertices=component_xyz.tolist(),faces=component_faces.tolist(),source_paper_mesh=str(source),source_paper_mesh_sha256=source_sha,
 adapter='Topmost actual face-centre-fan ray intersection and exact barycentric sample; no average-height projection.',
 paper_graph_fraction=.88,filled_inflation_fraction=.12,single_C2_port_envelope=True,source_closed_mesh_retained=True,
 closed_component_topology_transferred_to_height_graph=False,projection_holes_retained_as_filled_depressions=True,
 full_component_has_overhangs_but_adapter_is_single_valued=True))
shutil.copyfile(OLD/'canonical_host.json',OUT/'canonical_host.json');shutil.copyfile(OLD/'actual_tissue_worker.py',OUT/'actual_tissue_worker.py')
for pp in (Path(__file__).resolve(),OLD/'actual_tissue_worker.py'):
 shutil.copyfile(pp,OUT/'source_snapshot'/pp.name)
job=OUT/'job.json';write(job,dict(external_root=str(EXTERNAL),host=str(OUT/'canonical_host.json'),component=str(component),output=str(OUT/'ACTUAL_TISSUE_GENERATED_CELL.json'),max_faces=200000))
cache=OUT/'temp';cache.mkdir()
args=[str(EXTERNAL/'blender-4.5.4-windows-x64/blender.exe'),'--background','--factory-startup','--threads','4','--python-exit-code','1','--python',str(OUT/'actual_tissue_worker.py'),'--',str(job)]
with (OUT/'actual_tissue.log').open('x',encoding='utf-8') as log:
 subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180,env=dict(os.environ,TEMP=str(cache),TMP=str(cache)))
data=json.loads((OUT/'ACTUAL_TISSUE_GENERATED_CELL.json').read_text(encoding='utf-8'));a=np.asarray(data['vertices'],float)
ii=np.rint(a[:,0]*32).astype(int);jj=np.rint(a[:,1]*32).astype(int)
if np.max(abs(a[:,0]*32-ii))>1e-5 or np.max(abs(a[:,1]*32-jj))>1e-5:raise ValueError('Actual Tissue material samples changed.')
grid=np.full((33,65),np.nan)
for i,j,h in zip(ii,jj,a[:,2]):
 if np.isfinite(grid[j,i]) and abs(grid[j,i]-h)>1e-7:raise ValueError('Actual Tissue height graph is not single-valued.')
 grid[j,i]=h
if not np.isfinite(grid).all():raise ValueError('Actual Tissue output graph has an aperture.')
first,second=grid[:,:33],grid[:,32:]
if np.max(abs(first-second))>2e-7 or np.any(first[0]!=0) or np.any(first[-1]!=0) or np.any(first[:,0]!=0) or np.any(first[:,-1]!=0):raise ValueError('Repeated Tissue cells or exact C2 ports differ.')
np.savez(OUT/'ACTUAL_TISSUE_HEIGHT_GRID.npz',height=first,uv=np.linspace(0,1,33))
if sha(source)!=source_sha:raise ValueError('Preserved full paper mesh changed.')
receipt=dict(kind='ACTUAL_PAPER_DERIVED_UPSTREAM_TISSUE_QUAD_LAST_COMPONENT',actual_Tissue_call_succeeded=True,
 generated_source=str(OUT/'ACTUAL_TISSUE_GENERATED_CELL.json'),generated_source_sha256=sha(OUT/'ACTUAL_TISSUE_GENERATED_CELL.json'),
 height_grid=str(OUT/'ACTUAL_TISSUE_HEIGHT_GRID.npz'),height_grid_sha256=sha(OUT/'ACTUAL_TISSUE_HEIGHT_GRID.npz'),
 input_component=str(component),input_component_sha256=sha(component),actual_operator=data['operator'],Tissue_version=data['tissue_version'],checks=data['checks'],
 source_paper_receipt=dict(path=str(PAPER/'PAPER_COMPONENT_RECEIPT.json'),sha256=sha(PAPER/'PAPER_COMPONENT_RECEIPT.json')),
 source_closed_component=dict(path=str(source),sha256=source_sha),
 seed_manifold_validation=dict(path=str(PAPER/'SEED_TO_SOLID_VALIDATION.json'),sha256=sha(PAPER/'SEED_TO_SOLID_VALIDATION.json')),
 exact_top_ray_adapter=dict(path=str(OUT/'PAPER_EXACT_TOP_RAY_ADAPTER.npz'),sha256=sha(OUT/'PAPER_EXACT_TOP_RAY_ADAPTER.npz')),
 projection_actual_hit_samples=int(hit.sum()),projection_samples=1089,projection_multilayer_samples=int(np.count_nonzero(layers>1)),
 source_closed_component_genus=119,closed_3D_asset_preserved=True,closed_topology_transferred_to_whole=False,
 topmost_rays_not_average_height=True,geometry_nearest_correspondence=False,paper_graph_fraction=.88,filled_inflation_fraction=.12,
 single_C2_envelope=True,no_duplicate_unit_outer_tapers=True,exact_zero_outer_edge_height=True,
 raw_height_max=float(first.max()),normalized_height_quantiles=np.quantile(first/first.max(),[0,.1,.25,.5,.75,.9,1]).tolist(),
 old_component_scaled_or_relabelled=False,whole_model_not_yet_assembled=True,original_host_XYZ_smoothed=False,
 limits=['A single-valued UV height graph retains sampled relief but cannot transfer the closed component handles or overhang topology.',
         'The full actual 3D paper component remains an independent source asset. Empty ray columns become low filled depressions.'],
 generator=dict(path=str(Path(__file__).resolve()),sha256=sha(__file__)),elapsed_seconds=time.perf_counter()-started)
write(OUT/'ACTUAL_TISSUE_RECEIPT.json',receipt)
print('ACTUAL_PAPER_TISSUE_READY',data['checks'],receipt['normalized_height_quantiles'],time.perf_counter()-started,flush=True)
