"""Finish the completed history calculation after the bounded transport fix."""
from pathlib import Path
import sys,json,time,shutil,numpy as np
sys.dont_write_bytecode=True
from run_history_classification import HERE,STATES,TISSUE,OLD_ANALYSIS,CHUNK,sha,record,write,lift_probabilities,mapped
from history_classifier import HistoryConfig,contract
def main():
 started=time.perf_counter()
 if (HERE/'CLASSIFICATION_RECEIPT.json').exists():raise FileExistsError('Completed receipt preserved.')
 with np.load(HERE/'SOURCE5_WEIGHTS_G3.npz',allow_pickle=False) as z:
  prior=z['old_weights'];posterior=z['new_weights'];no_early=z['no_early_weights'];body=z['source_body'];confidence=z['history_confidence']
 with np.load(HERE/'AUTHORED_STAGE_RESIDUALS.npz',allow_pickle=False) as z:
  neutral_checks={key:float(np.max(abs(z[key]))) for key in ('G3_to_G4','G6middle_to_G7surface')}
 if max(neutral_checks.values())>1e-9:raise ValueError('Neutral replay evidence failed.')
 hoststats=json.loads((HERE/'TISSUE_HOSTS.json').read_text(encoding='utf-8'))['counts']
 config=HistoryConfig(radius=.45,length_scale=9.735842284057451)
 q3=mapped(STATES/'G03_SIDEWALL/control_quad.npz','faces')
 sources={str(p):sha(p) for p in [HERE/'SOURCE5_WEIGHTS_G3.npz',HERE/'HISTORY_FEATURES.npz',HERE/'AUTHORED_STAGE_RESIDUALS.npz',
    HERE/'TISSUE_HOSTS.json',HERE/'TISSUE_HOSTS.npz',OLD_ANALYSIS/'ANALYSIS_RECEIPT.json',OLD_ANALYSIS/'EXACT_EARLY_ANCESTRY.npz']}
 operators={}
 for stage in ['G03_SIDEWALL','G04_NEUTRAL','G05_DIRECTIONAL','G06_DEPTH08','G06_MIDDLE','G07_SURFACE']:
  gp=STATES/stage/'generation.json';cp=STATES/stage/'control_quad.npz';sources[str(gp)]=sha(gp);sources[str(cp)]=sha(cp)
  operators[stage]=json.loads(gp.read_text(encoding='utf-8'))
 outputs=lift_probabilities(posterior,q3,sources)
 oldarg=np.argmax(prior[body],1);newarg=np.argmax(posterior[body],1)
 difference=np.sum(abs(posterior-prior),axis=1);earlydifference=np.sum(abs(posterior-no_early),axis=1);valid=confidence>=.5
 stats=dict(SOURCE_body_faces=int(body.sum()),dominant_changed_faces=int(np.sum(oldarg!=newarg)),dominant_changed_fraction=float(np.mean(oldarg!=newarg)),
   old_to_new_dominant_confusion=np.bincount(5*oldarg+newarg,minlength=25).reshape(5,5).tolist(),
   posterior_L1_quantiles=np.quantile(difference[body],[0,.1,.5,.9,1]).tolist(),
   early_term_on_off_L1_quantiles=np.quantile(earlydifference[body],[0,.1,.5,.9,1]).tolist(),
   early_term_changes_dominant_faces=int(np.sum(body&(np.argmax(posterior,1)!=np.argmax(no_early,1)))),
   history_confidence_at_least_050_faces=int(np.sum(body&valid)),
   changed_dominant_at_confidence_050=int(np.sum(body&valid&(np.argmax(prior,1)!=np.argmax(posterior,1)))))
 snapshots={};snap=HERE/'source_snapshot';snap.mkdir()
 for path in [Path(__file__),HERE/'run_history_classification.py',HERE/'run_history_classification_failed_transport.py',HERE/'history_classifier.py']:
  value=sha(path);shutil.copyfile(path,snap/path.name);snapshots[str(path)]=value
 write('CLASSIFICATION_RECEIPT.json',dict(kind='ACTUAL_MULTIGENERATION_AUTHORED_HISTORY_SOURCE_CLASSIFICATION',prototype=True,
   config=contract(config),source_hashes=sources,source_snapshots=snapshots,actual_stage_operator_metadata=operators,
   neutral_replay_maximum_errors=neutral_checks,exact_material_ancestry_receipt=record(OLD_ANALYSIS/'ANALYSIS_RECEIPT.json'),
   scalar_lineage_receipt=record(TISSUE/'UV_LINEAGE_RECEIPT.json'),outputs=outputs,
   G3_weights=record(HERE/'SOURCE5_WEIGHTS_G3.npz'),features=record(HERE/'HISTORY_FEATURES.npz'),
   authored_stage_residuals=record(HERE/'AUTHORED_STAGE_RESIDUALS.npz'),Tissue_hosts=record(HERE/'TISSUE_HOSTS.json'),
   old_new_classification=stats,Tissue_host_changes=hoststats,classification_actually_changed=stats['dominant_changed_faces']>0,
   feature_birth_claimed=False,current22_and_wholeCC1_preserved=True,
   scalar_transport='Actual G3 incident-face average and saved V/E/F lineage toG4/G5/G6/G7; quintic-normalized continuous five weights atG6/G7.',
   early_evidence_effect='Actual G2/G3/G4/G5 normal-turning and one-axis persistence affect posterior; explicit no-early ablation is saved.',
   completed_history_arrays_reused_without_reanalysis=True,
   transport_recovery='Failed old-V target slice lacked final stop. Failed source and incompleteG4 preserved; completedG3/features/hosts remain unchanged; corrected transport resumed.',
   limitations=['Observed normal distributions are not a curvature fit or absolute age.','Authored residual includes vertex placement and fields, not isolated physical fold generation.',
    'NewSOURCE Tissue hosts are history-complex candidates, not certified forks.','Global length scale/radius are fixture config; generic helper has no project paths/seed IDs.'],
   elapsed_seconds_since_transport_resume=time.perf_counter()-started))
 print('HISTORY_CLASSIFICATION_COMPLETE',stats,hoststats,time.perf_counter()-started,flush=True)
if __name__=='__main__':main()
