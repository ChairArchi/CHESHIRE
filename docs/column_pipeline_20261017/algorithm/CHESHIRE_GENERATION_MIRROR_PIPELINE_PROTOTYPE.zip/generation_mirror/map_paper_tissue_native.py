﻿"""New actual paper/Tissue grid -> exact G7 native scalar fields, before guards.
Host weights apply once. No flow guard, cap, geometry smoothing, or host
coordinate displacement occurs in this mapper; whole assembly owns guards.
"""
from pathlib import Path
import sys,argparse,json,hashlib,shutil,time
sys.dont_write_bytecode=True
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'paper_tissue_native'
TISSUE=ROOT/'paper_tissue'
OLD=Path(r'E:\CHESHIRE_DATA\experiments\whole_tissue_relief_20261016')
BASE=Path(r'E:\CHESHIRE_DATA\experiments\fold_aligned_mandel_20261015')
HOST=Path(r'E:\CHESHIRE_DATA\experiments\parent_nested_folds_20261014\trial02\NESTED\control_quad.npz')
STATES=Path(r'E:\CHESHIRE_DATA\experiments\end_rule_revision_20261014\trial01\replay\states')
HOST_SHA='0092aaf46018411a0008156cc52d223dd25f2ca3192ae7ccc25e21f0afc385d3'


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()


def binding(p):return dict(path=str(p),sha256=sha(p))


def write(p,r):Path(p).write_text(json.dumps(r,ensure_ascii=True,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def choose_orientation(fids,phase_duv):
 old_path=OLD/'broad_component_v21/FACE_UV_ORIENTATION_V21.npz'
 old_record=json.loads((OLD/'broad_component_v21/TISSUE_RAW_SCALAR_RECEIPT_V21.json').read_text(encoding='utf-8'))
 if sha(old_path)!=old_record['orientation']['sha256']:raise ValueError('Original retained-host UV orientations changed.')
 with np.load(old_path) as data:
  lookup={int(fid):(bool(sw),int(mode),axis) for fid,sw,mode,axis in zip(data['face_ids'],data['swap_uv'],data['direction_mode'],data['flow_axis'])}
 metric_path=OLD/'SHARED_G3_SHAPE_METRICS.npz'
 with np.load(metric_path) as d:q=d['faces'];x=d['xyz'];centers=d['centers'];normals=d['normals']
 edges=np.sort(np.stack([q,np.roll(q,-1,axis=1)],axis=2).reshape(-1,2),axis=1)
 _,inv,count=np.unique(edges,axis=0,return_inverse=True,return_counts=True)
 if not np.all(count==2):raise ValueError('Actual closed G3 geometry required for orientation fallback.')
 pairs=np.argsort(inv,kind='stable').reshape(-1,2)//4;nb=[set() for _ in q]
 for a,b in pairs:nb[a].add(int(b));nb[b].add(int(a))
 swap=np.zeros(len(fids),bool);modes=np.zeros(len(fids),np.int8);axes=np.zeros((len(fids),3));retained=np.zeros(len(fids),bool)
 for k,f in enumerate(fids):
  if int(f) in lookup:
   swap[k],modes[k],axes[k]=lookup[int(f)];retained[k]=True;continue
  p=x[q[f]];u=(p[1]+p[2]-p[0]-p[3])*.5;v=(p[2]+p[3]-p[0]-p[1])*.5
  du,dv=phase_duv[k];axis=None
  if np.isfinite([du,dv]).all() and np.hypot(du,dv)>1e-9:
   axis=-dv*u+du*v
   if np.linalg.norm(axis)>1e-12:axis/=np.linalg.norm(axis);modes[k]=1
   else:axis=None
  if axis is None:
   n=normals[f];world=np.eye(3)[int(np.argmin(abs(n)))];ex=np.cross(n,world);ex/=np.linalg.norm(ex);ey=np.cross(n,ex);basis=np.stack([ex,ey],axis=1)
   near=set(nb[f])
   for j in nb[f]:near.update(nb[j])
   near.discard(int(f));ids=np.array(sorted(near),int)
   dp=(centers[ids]-centers[f])@basis;dn=(normals[ids]-n)@basis;B,_,rank,_=np.linalg.lstsq(dp,dn,rcond=1e-7)
   if rank==2:
    eig,vec=np.linalg.eigh(-.5*(B+B.T));axis=basis@vec[:,int(np.argmin(abs(eig)))];modes[k]=2
   else:axis=u/np.linalg.norm(u);modes[k]=3
  swap[k]=abs(v@axis)/(np.linalg.norm(v)+1e-15)>abs(u@axis)/(np.linalg.norm(u)+1e-15);axes[k]=axis
 return swap,modes,axes,retained,binding(old_path),binding(metric_path)


def main():
 p=argparse.ArgumentParser();p.add_argument('--hosts',type=Path,default=ROOT/'history_classification/TISSUE_HOSTS.npz');args=p.parse_args()
 started=time.perf_counter()
 if OUT.exists():raise FileExistsError('Preserve completed new paper native fields.')
 if sha(HOST)!=HOST_SHA:raise ValueError('Original NESTED host changed.')
 plugin=json.loads((TISSUE/'ACTUAL_TISSUE_RECEIPT.json').read_text(encoding='utf-8'))
 if not plugin['actual_Tissue_call_succeeded'] or sha(plugin['height_grid'])!=plugin['height_grid_sha256'] or sha(plugin['generated_source'])!=plugin['generated_source_sha256']:raise ValueError('New actual paper Tissue provenance failed.')
 with np.load(plugin['height_grid']) as d:grid=d['height']
 if grid.shape!=(33,33) or grid.max()<=0 or np.any(grid[0]!=0) or np.any(grid[-1]!=0) or np.any(grid[:,0]!=0) or np.any(grid[:,-1]!=0):raise ValueError('Actual Tissue grid has invalid exact G3 ports.')
 uv=np.load(OLD/'UV_PATTERN.npy');proof=json.loads((OLD/'UV_LINEAGE_RECEIPT.json').read_text(encoding='utf-8'))
 with np.load(HOST) as d:q=d['faces'];nv=len(d['xyz'])
 qhash=hashlib.sha256(memoryview(np.ascontiguousarray(q)).cast('B')).hexdigest()
 if uv.shape!=(256,4,2) or nv!=7002114 or len(q)!=27352*256 or proof['G7_faces_sha256']!=qhash or not proof['exact_original_NESTED_quad_faces_match'] or proof['pattern_sha256']!=sha(OLD/'UV_PATTERN.npy') or not all(s['all_constructed_child_quads_exact'] for s in proof['stages']):raise ValueError('Actual saved G3-to-G7 material lineage changed.')
 host_binding=binding(args.hosts.resolve())
 with np.load(args.hosts) as d:
  fids=d['face_ids'];weights=d['face_weights'];amp=d['normal_height_amplitude'];phase=d['phase_dUV']
 if len(np.unique(fids))!=len(fids) or np.any(fids<0) or np.any(fids>=27352) or weights.shape!=(len(fids),) or amp.shape!=(len(fids),) or phase.shape!=(len(fids),2):raise ValueError('New actual G3 host field dimensions invalid.')
 if not np.isfinite(weights).all() or np.any(weights<0) or np.any(weights>1) or np.any(amp<.04-1e-12) or np.any(amp>.06+1e-12):raise ValueError('Physical .04-.06 Tissue budgets and normalized host priorities required.')
 swap,modes,axes,retained,old_orientation,metric_binding=choose_orientation(fids,phase)
 OUT.mkdir();(OUT/'source_snapshot').mkdir();shutil.copyfile(__file__,OUT/'source_snapshot'/Path(__file__).name)
 orientation=OUT/'FACE_UV_ORIENTATION.npz';np.savez(orientation,face_ids=fids,swap_uv=swap,direction_mode=modes,flow_axis=axes,retained_old_orientation=retained,actual_phase_dUV=phase)
 lo=np.full(nv,np.inf);hi=np.zeros(nv);priority=np.zeros(nv);semantic=np.zeros(nv,bool);ports=np.zeros(nv,bool)
 for start in range(0,len(fids),64):
  stop=min(start+64,len(fids));fs=fids[start:stop];take=(fs[:,None]*256+np.arange(256)[None,:]).reshape(-1);ids=q[take].reshape(-1)
  uu=np.broadcast_to(uv[None],(len(fs),256,4,2));su,sv=uu[:,:,:,0],uu[:,:,:,1]
  gu=np.where(swap[start:stop,None,None],sv,su);gv=np.where(swap[start:stop,None,None],su,sv)
  fu=gu*32;fv=gv*32;i=np.minimum(fu.astype(int),31);j=np.minimum(fv.astype(int),31);a=fu-i;b=fv-j
  normalized=((1-a)*(1-b)*grid[j,i]+a*(1-b)*grid[j,i+1]+(1-a)*b*grid[j+1,i]+a*b*grid[j+1,i+1])/grid.max()
  w=np.clip(normalized,0,1)*weights[start:stop,None,None];h=w*amp[start:stop,None,None]
  boundary=(su==0)|(su==1)|(sv==0)|(sv==1);w[boundary]=0.;h[boundary]=0.;ports[ids[boundary.reshape(-1)]]=True
  np.minimum.at(lo,ids,h.reshape(-1));np.maximum.at(hi,ids,h.reshape(-1));np.maximum.at(priority,ids,w.reshape(-1));semantic[ids]=True
 assigned=np.isfinite(lo);error=float(np.max(hi[assigned]-lo[assigned],initial=0))
 if error>5e-12:raise ValueError('Shared actual G7 vertex heights disagree across exact cell UVs.')
 rep_path=BASE/'trial03b_refined/working_arrays/4_representatives.npy';rep=np.load(rep_path,mmap_mode='r')
 with np.load(STATES/'G07_SURFACE/evidence.npz') as d:px=d['mirror_x_vertex_pairs'];py=d['mirror_y_vertex_pairs']
 height=np.asarray(hi[rep]);priority=np.asarray(priority[rep]);semantic=semantic|semantic[px]|semantic[py]|semantic[px[py]];ports=ports|ports[px]|ports[py]|ports[px[py]]
 if np.any(height[~semantic]!=0) or np.any(priority[~semantic]!=0) or np.any(height[ports]!=0) or np.any(priority[ports]!=0):raise ValueError('Native field escaped semantic hosts or exact G3 ports.')
 if np.any(height!=height[px]) or np.any(height!=height[py]) or np.any(priority!=priority[px]) or np.any(priority!=priority[py]):raise ValueError('Actual scalar reflection transport failed.')
 hp=OUT/'TISSUE_RAW_HEIGHT.npy';wp=OUT/'TISSUE_PRIORITY_WEIGHT.npy';np.save(hp,height);np.save(wp,priority)
 semantic_path=OUT/'TISSUE_SEMANTIC_CONTROL_IDS.npy';port_path=OUT/'TISSUE_G3_PORT_CONTROL_IDS.npy';np.save(semantic_path,np.flatnonzero(semantic));np.save(port_path,np.flatnonzero(ports))
 if sha(args.hosts)!=host_binding['sha256']:raise ValueError('New semantic hosts changed during mapping.')
 positive=height>0;semheight=height[semantic]
 record=dict(kind='NEW_ACTUAL_PAPER_TISSUE_EXACT_G7_RAW_FIELDS_BEFORE_GUARDS',height=binding(hp),priority=binding(wp),
  host_control_vertices=nv,host_control_quad=binding(HOST),host_quad_faces_sha256=qhash,
  actual_Tissue_receipt=binding(TISSUE/'ACTUAL_TISSUE_RECEIPT.json'),actual_generated_height_grid=binding(Path(plugin['height_grid'])),
  source_paper_receipt=plugin['source_paper_receipt'],source_closed_component=plugin['source_closed_component'],
  semantic_hosts=host_binding,semantic_host_count=len(fids),UV_pattern=binding(OLD/'UV_PATTERN.npy'),UV_lineage=binding(OLD/'UV_LINEAGE_RECEIPT.json'),
  orientation=binding(orientation),original_orientation=old_orientation,actual_orientation_metric=metric_binding,
  actual_registered_phase_evidence=binding(STATES/'G07_SURFACE/evidence.npz'),reflection_representatives=binding(rep_path),
  original_hosts_with_retained_orientation=int(retained.sum()),new_hosts_with_measured_orientation=int((~retained).sum()),
  orientation_mode_counts={str(k):int(np.count_nonzero(modes==k)) for k in (1,2,3)},
  orientation_rule='Keep original orientation for admitted original hosts. New hosts use actual registered phase isophase tangent (-dv*U+du*V); zero/invalid phase uses actual two-ring low-absolute-curvature tangent, then physical host U fallback.',
  physical_peak_budget=[.04,.06],cell_frequency=1.,G3_ports_exact_zero=True,shared_vertex_height_max_error=error,
  native_reflection_exact=True,semantic_controls=int(semantic.sum()),positive_height_controls=int(positive.sum()),
  positive_height_quantiles=np.quantile(height[positive],[0,.1,.25,.5,.75,.9,1]).tolist(),
  semantic_height_quantiles=np.quantile(semheight,[0,.1,.25,.5,.75,.9,1]).tolist(),
  height_already_semantically_weighted_once=True,priority_already_semantically_weighted_once=True,
  flow_guards_applied=False,cap_guards_applied=False,safety_cap_applied=False,whole_geometry_not_yet_changed=True,
  previous_Tissue_field_reused=False,source_grid_from_new_actual_paper_and_actual_Tissue=True,
  complete_closed_component_topology_transferred_to_height_graph=False,
  generator=binding(Path(__file__).resolve()),elapsed_seconds=time.perf_counter()-started)
 write(OUT/'RAW_TISSUE_RECEIPT.json',record)
 print('NEW_PAPER_NATIVE_RAW_READY',len(fids),int(positive.sum()),record['positive_height_quantiles'],error,time.perf_counter()-started,flush=True)


if __name__=='__main__':main()
