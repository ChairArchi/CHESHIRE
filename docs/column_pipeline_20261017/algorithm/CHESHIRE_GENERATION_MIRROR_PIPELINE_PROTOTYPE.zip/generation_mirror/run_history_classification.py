"""Fixture adapter: actual stage-history classifier and exact G3->G6/G7 fields."""
from pathlib import Path
import sys,json,hashlib,time,shutil
sys.dont_write_bytecode=True
import numpy as np
from scipy.sparse import csr_matrix
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD_ANALYSIS=Path(r'E:\CHESHIRE_DATA\experiments\interleaved_mandel_subdivision_20261016\generation_analysis')
STATES=Path(r'E:\CHESHIRE_DATA\experiments\end_rule_revision_20261014\trial01\replay\states')
TISSUE=Path(r'E:\CHESHIRE_DATA\experiments\whole_tissue_relief_20261016')
CURRENT=Path(r'E:\CHESHIRE_DATA\experiments\fold_aligned_mandel_20261015\variant22_flow_corrected_visible_relief_whole_hybrid_20261016')
NESTED=Path(r'E:\CHESHIRE_DATA\experiments\parent_nested_folds_20261014\trial02\NESTED\control_quad.npz')
sys.path.insert(0,r'E:\CHESHIRE_DATA\experiments\whole_cc1_prototype_20261016')
from prepare_whole_cc1_20261016 import mapped
from history_classifier import HistoryConfig,history_features,reweight_history_classes,select_tissue_hosts,neutral_retained_predictions,contract,smooth
CHUNK=65536
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def ah(a):return hashlib.sha256(memoryview(np.ascontiguousarray(a)).cast('B')).hexdigest()
def record(p):return dict(path=str(p),sha256=sha(p))
def write(name,data):
 with (HERE/name).open('x',encoding='utf-8') as f:json.dump(data,f,indent=2,ensure_ascii=False,allow_nan=False)
def orbit_average(a,mx,my):
 return .25*(a+a[mx]+a[my]+a[mx[my]])
def lift_probabilities(face_weights,q3,sources):
 nv3=int(q3.max())+1;count=np.zeros(nv3);v=np.zeros((nv3,5))
 for k in range(4):np.add.at(v,q3[:,k],face_weights);np.add.at(count,q3[:,k],1)
 v/=count[:,None];prior=v
 outputs={}
 for level,stage in [(4,'G04_NEUTRAL'),(5,'G05_DIRECTIONAL'),(6,'G06_DEPTH08'),(7,'G07_SURFACE')]:
  ep=STATES/stage/'evidence.npz';sources[str(ep)]=sha(ep);edges=mapped(ep,'input_edges')
  input_path=STATES/({4:'G03_SIDEWALL',5:'G04_NEUTRAL',6:'G05_DIRECTIONAL',7:'G06_MIDDLE'}[level])/'control_quad.npz'
  q=mapped(input_path,'faces');nv=len(prior);ne=len(edges);nf=len(q)
  p=HERE/('SOURCE5_G%d.npy'%level)
  out=np.lib.format.open_memmap(p,mode='w+',dtype=np.float64,shape=(nv+ne+nf,5))
  for start in range(0,nv,CHUNK):
   stop=min(start+CHUNK,nv);out[start:stop]=prior[start:stop]
  for start in range(0,ne,CHUNK):
   stop=min(ne,start+CHUNK);out[nv+start:nv+stop]=np.asarray(prior[np.asarray(edges[start:stop])]).mean(1)
  for start in range(0,nf,CHUNK):
   stop=min(nf,start+CHUNK);out[nv+ne+start:nv+ne+stop]=np.asarray(prior[np.asarray(q[start:stop])]).mean(1)
  out.flush()
  if level in (6,7):
   for start in range(0,len(out),CHUNK):
    a=np.clip(np.asarray(out[start:start+CHUNK]),0,1);a=smooth(a);a/=np.maximum(a.sum(1,keepdims=True),1e-30);out[start:start+CHUNK]=a
   out.flush();outputs['SOURCE5_G%d'%level]=dict(path=str(p),sha256=sha(p),shape=list(out.shape),dtype=str(out.dtype))
  prior=out
  print('HISTORY_CLASS_SCALAR_LIFT_READY',level,len(out),flush=True)
 return outputs
def main():
 started=time.perf_counter()
 if (HERE/'CLASSIFICATION_RECEIPT.json').exists():raise FileExistsError('Completed history class experiment preserved.')
 cached_path=OLD_ANALYSIS/'MULTIGENERATION_STRUCTURE.npz';ancestry_path=OLD_ANALYSIS/'EXACT_EARLY_ANCESTRY.npz'
 cache_receipt=json.loads((OLD_ANALYSIS/'ANALYSIS_RECEIPT.json').read_text(encoding='utf-8'))
 if sha(cached_path)!=cache_receipt['data']['sha256']:raise ValueError('Earlier exact material-anchor cache changed.')
 with np.load(cached_path,allow_pickle=False) as z:cache={k:z[k] for k in z.files}
 with np.load(ancestry_path,allow_pickle=False) as z:early={k:z[k] for k in z.files}
 with np.load(TISSUE/'SOURCEZONES.npz',allow_pickle=False) as z:zones={k:z[k] for k in z.files}
 source=cache['SOURCE_face'];events=cache['events'];caps=zones['face_class_ids']==0;body=source&~caps
 c=cache['centres'];normal=cache['normals'];anchors=cache['anchor_vertex_ids'];nf=len(anchors)
 sources={str(cached_path):sha(cached_path),str(ancestry_path):sha(ancestry_path),str(TISSUE/'SOURCEZONES.npz'):sha(TISSUE/'SOURCEZONES.npz'),
   str(OLD_ANALYSIS/'ANALYSIS_RECEIPT.json'):sha(OLD_ANALYSIS/'ANALYSIS_RECEIPT.json')}
 stage_names=['G03_SIDEWALL','G04_NEUTRAL','G05_DIRECTIONAL','G06_DEPTH08','G06_MIDDLE','G07_SURFACE']
 coords={};quads={};operators={}
 for stage in stage_names:
  p=STATES/stage/'control_quad.npz';sources[str(p)]=sha(p);coords[stage]=mapped(p,'xyz');quads[stage]=mapped(p,'faces')
  gp=STATES/stage/'generation.json';sources[str(gp)]=sha(gp);operators[stage]=json.loads(gp.read_text(encoding='utf-8'))
 if ah(quads['G06_DEPTH08'])!=ah(quads['G06_MIDDLE']):raise ValueError('G6 coordinate-only stage topology differs.')
 if not np.array_equal(quads['G03_SIDEWALL'],zones['faces']):raise ValueError('Actual G3 classification topology differs.')
 residuals={};predictions={};counts={}
 residuals['G3_to_G4']=c[4]-c[3]
 for name,previous,current,actual in [
   ('G4_to_G5','G04_NEUTRAL','G05_DIRECTIONAL',c[5]),
   ('G5_to_G6depth','G05_DIRECTIONAL','G06_DEPTH08',np.asarray(coords['G06_DEPTH08'][anchors])),
   ('G6middle_to_G7surface','G06_MIDDLE','G07_SURFACE',c[7])]:
  pred,norm,degree=neutral_retained_predictions(coords[previous],quads[previous],anchors,CHUNK)
  predictions[name]=pred;residuals[name]=actual-pred;counts[name]=np.unique(degree).tolist()
 middle=c[6]-np.asarray(coords['G06_DEPTH08'][anchors]);late=c[8]-c[7]
 residuals['G6depth_to_G6middle']=middle;residuals['G7surface_to_nested']=late
 neutral_checks={key:float(np.max(np.abs(residuals[key]))) for key in ('G3_to_G4','G6middle_to_G7surface')}
 if max(neutral_checks.values())>1e-9:raise ValueError('Actual declared neutral stage does not replay neutral CC at exact anchors.')
 f=cache['reference_dual_edge_faces'];length=cache['reference_surface_route_length']
 graph=csr_matrix((np.r_[length,length],(np.r_[f[:,0],f[:,1]],np.r_[f[:,1],f[:,0]])),shape=(nf,nf))
 q3=quads['G03_SIDEWALL'];refprefix=zones['xyz'];area=np.linalg.norm(np.cross(refprefix[q3[:,1]]-refprefix[q3[:,0]],refprefix[q3[:,3]]-refprefix[q3[:,0]]),axis=1)
 wallparent=mapped(STATES/'G03_WALL/evidence.npz','parent_face');g2parent=np.full(nf,-1,np.int64);g2parent[source]=wallparent[early['G3_face_to_WALL'][source]]
 config=HistoryConfig(radius=.45,length_scale=9.735842284057451)
 print('ACTUAL_AUTHORED_HISTORY_READY',neutral_checks,flush=True)
 features=history_features(c[8],normal[3],normal[[2,3,4,5]],g2parent,graph,area,middle,late,
   np.stack((residuals['G3_to_G4'],residuals['G4_to_G5'],residuals['G5_to_G6depth'])),config,
   progress=lambda i,n:print('HISTORY_FEATURE_PROGRESS',i,n,flush=True))
 prior=np.zeros((nf,5));cls=zones['face_class_ids'];good=(cls>=1)&(cls<=5);prior[good,cls[good]-1]=1.;prior[~good,1]=1.
 posterior,evidence=reweight_history_classes(prior,features,config,use_early=True)
 no_early,_=reweight_history_classes(prior,features,config,use_early=False)
 evpath=STATES/'G03_SIDEWALL/evidence.npz';sources[str(evpath)]=sha(evpath)
 mx=mapped(evpath,'mirror_x_face_pairs');my=mapped(evpath,'mirror_y_face_pairs')
 posterior=orbit_average(posterior,mx,my);posterior/=posterior.sum(1,keepdims=True)
 no_early=orbit_average(no_early,mx,my);no_early/=no_early.sum(1,keepdims=True)
 selected,priority,reason,hostscore=select_tissue_hosts(posterior,evidence,events,caps,graph,config)
 selected=selected|selected[mx]|selected[my]|selected[mx[my]]
 priority=np.maximum.reduce((priority,priority[mx],priority[my],priority[mx[my]]));priority[~selected]=0
 reason=np.maximum.reduce((reason,reason[mx],reason[my],reason[mx[my]]))
 oldhostdoc=json.loads((TISSUE/'VERIFIED_G3_TISSUE_HOSTS.json').read_text(encoding='utf-8'));oldhostpath=Path(oldhostdoc['host_mask'])
 with np.load(oldhostpath,allow_pickle=False) as z:oldids=z['face_ids']
 oldmask=np.zeros(nf,bool);oldmask[oldids]=True
 phase=mapped(STATES/'G07_SURFACE/evidence.npz','parent_phase')[:len(coords['G03_SIDEWALL'])]
 ph=phase[q3];phase_uv=np.column_stack((.5*(ph[:,1]+ph[:,2]-ph[:,0]-ph[:,3]),.5*(ph[:,2]+ph[:,3]-ph[:,0]-ph[:,1])))
 amp=.04+.02*smooth((features['middle_RMS']/config.length_scale-.0005)/.002)
 allfeatures=dict(features,**evidence);allfeatures.update(events=events,source_caps=caps,old_class_ids=cls,G2_parent_face=g2parent,phase_dUV=phase_uv,
    anchor_vertex_ids=anchors,centres=c[8],early_stage_names=np.array(['G2','G3','G4','G5']))
 np.savez(HERE/'HISTORY_FEATURES.npz',**allfeatures)
 np.savez(HERE/'AUTHORED_STAGE_RESIDUALS.npz',**residuals,**{'neutral_prediction_'+k:v for k,v in predictions.items()})
 np.savez(HERE/'SOURCE5_WEIGHTS_G3.npz',old_weights=prior,new_weights=posterior,no_early_weights=no_early,history_confidence=features['history_confidence'],
    early_confidence=features['early_confidence'],source_body=body,events=events,source_caps=caps)
 ids=np.flatnonzero(selected);np.savez(HERE/'TISSUE_HOSTS.npz',face_ids=ids,face_weights=priority[ids],normal_height_amplitude=amp[ids],phase_dUV=phase_uv[ids],
   shape_weights=posterior[ids],reason_codes=reason[ids],host_score=hostscore[ids])
 np.save(HERE/'TISSUE_HOST_PRIORITY_G3.npy',priority)
 hoststats=dict(selected_faces=int(selected.sum()),actual_event_faces=int(np.sum(selected&(events>0))),interface_faces=int(np.sum((reason==2)&selected)),
   new_history_SOURCE_faces=int(np.sum((reason==3)&selected)),old_host_faces=int(oldmask.sum()),added_vs_old=int(np.sum(selected&~oldmask)),removed_vs_old=int(np.sum(oldmask&~selected)))
 write('TISSUE_HOSTS.json',dict(kind='ACTUAL_EVENTS_INTERFACES_AND_HISTORY_COMPLEX_SOURCE_HOSTS',data=record(HERE/'TISSUE_HOSTS.npz'),
   full_priority=record(HERE/'TISSUE_HOST_PRIORITY_G3.npy'),counts=hoststats,columns=dict(face_ids='actual G3 SIDEWALL quad IDs',face_weights='one normalized admission weight [0,1]',
      normal_height_amplitude='explicit model-unit peak .04..06 from actual registered middle residual activity',phase_dUV='registered parent-phase exact four-corner mean derivatives in local material u,v'),
   new_host_orientation='Use actual phase_dUV; isophase majoraxis v if abs(du)>abs(dv), else u. Existing saved orientations may be retained for common hosts.',
   caps_excluded=True,final_G7_flow_guards_not_baked_in_twice=True,feature_birth_claimed=False))
 outputs=lift_probabilities(posterior,q3,sources)
 oldarg=np.argmax(prior[body],1);newarg=np.argmax(posterior[body],1);matrix=np.bincount(5*oldarg+newarg,minlength=25).reshape(5,5)
 difference=np.sum(abs(posterior-prior),axis=1);earlydifference=np.sum(abs(posterior-no_early),axis=1)
 valid=features['history_confidence']>=.5
 stats=dict(SOURCE_body_faces=int(body.sum()),dominant_changed_faces=int(np.sum(body&(np.argmax(prior,1)!=np.argmax(posterior,1)))),
   dominant_changed_fraction=float(np.mean(oldarg!=newarg)),old_to_new_dominant_confusion=matrix.tolist(),
   posterior_L1_quantiles=np.quantile(difference[body],[0,.1,.5,.9,1]).tolist(),
   early_term_on_off_L1_quantiles=np.quantile(earlydifference[body],[0,.1,.5,.9,1]).tolist(),
   early_term_changes_dominant_faces=int(np.sum(body&(np.argmax(posterior,1)!=np.argmax(no_early,1)))),
   history_confidence_at_least_050_faces=int(np.sum(body&valid)),changed_dominant_at_confidence_050=int(np.sum(body&valid&(np.argmax(prior,1)!=np.argmax(posterior,1)))))
 snapshots={};snap=HERE/'source_snapshot';snap.mkdir()
 for path in [Path(__file__),HERE/'history_classifier.py']:
  value=sha(path);shutil.copyfile(path,snap/path.name);snapshots[str(path)]=value
 write('CLASSIFICATION_RECEIPT.json',dict(kind='ACTUAL_MULTIGENERATION_AUTHORED_HISTORY_SOURCE_CLASSIFICATION',prototype=True,
   config=contract(config),source_hashes=sources,source_snapshots=snapshots,
   actual_stage_operator_metadata=operators,neutral_replay_maximum_errors=neutral_checks,anchor_incidence_degrees=counts,
   exact_material_ancestry_receipt=record(OLD_ANALYSIS/'ANALYSIS_RECEIPT.json'),
   scalar_lineage_receipt=record(TISSUE/'UV_LINEAGE_RECEIPT.json'),outputs=outputs,
   G3_weights=record(HERE/'SOURCE5_WEIGHTS_G3.npz'),features=record(HERE/'HISTORY_FEATURES.npz'),
   authored_stage_residuals=record(HERE/'AUTHORED_STAGE_RESIDUALS.npz'),Tissue_hosts=record(HERE/'TISSUE_HOSTS.json'),
   old_new_classification=stats,Tissue_host_changes=hoststats,
   classification_actually_changed=True,feature_birth_claimed=False,current22_and_wholeCC1_preserved=True,
   scalar_transport='Actual G3 incident-face average; actual saved V/E/F lineage toG4/G5/G6/G7; quintic-normalized continuous five weights at G6 andG7.',
   early_evidence_effect='Actual G2/G3/G4/G5 normal-turning and one-axis persistence affect posterior; explicit no-early ablation is saved.',
   limitations=['Normal distribution statistics are observed evidence, not curvature-fit or absolute age.','Authored residual includes vertex placement and fields, not isolated physical fold generation.',
      'NewSOURCE Tissue hosts are history-complex shape candidates, not certified geometric forks.','Explicit global length scale/radius are fixture config; generic helper contains no file paths or seed IDs.'],
   elapsed_seconds=time.perf_counter()-started))
 print('HISTORY_CLASSIFICATION_COMPLETE',stats,hoststats,time.perf_counter()-started,flush=True)
if __name__=='__main__':main()
