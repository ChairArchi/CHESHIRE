﻿"""Portable Blender renderer for an adaptive-ornament geometry NPZ.

blender --background --factory-startup --python render_geometry.py --
  --input geometry.npz --output a_new_folder [--device CPU]

Reads actual xyz/quads and five-class fields. Changes materials only; no
subdivision, smoothing, normal maps, or geometry displacement are performed.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, sys, time
sys.dont_write_bytecode = True
import bpy
import numpy as np
from mathutils import Vector

PALETTE = [(.30,.32,.35,1),(.20,.55,.90,1),(.025,.48,.40,1),
           (.015,.09,.30,1),(.75,.46,.035,1),(.55,.07,.34,1)]
LABELS = ['protected boundary', 'calm', 'weak fold / transition',
          'strong coherent fold', 'rounded bulge', 'junction candidate']


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def array_hash(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def geometry_signature(obj):
    mesh = obj.data
    x = np.empty((len(mesh.vertices),3), np.float32)
    f = np.empty((len(mesh.polygons),3), np.int32)
    smooth = np.empty(len(mesh.polygons), bool)
    mesh.vertices.foreach_get('co', x.ravel())
    mesh.loops.foreach_get('vertex_index', f.ravel())
    mesh.polygons.foreach_get('use_smooth', smooth)
    return dict(vertices=len(x), triangles=len(f), xyz_float32_sha256=array_hash(x),
                faces_int32_sha256=array_hash(f), all_flat=not bool(smooth.any()),
                edges=len(mesh.edges), modifiers=len(obj.modifiers))


def material(name, rgba):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bs = mat.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value = rgba
    bs.inputs['Roughness'].default_value = .84
    return mat


def select_device(scene, requested):
    if requested == 'CPU':
        scene.cycles.device = 'CPU'
        scene.render.threads_mode = 'FIXED'
        scene.render.threads = 4
        return dict(backend='CPU', threads=4)
    pref = bpy.context.preferences.addons['cycles'].preferences
    for backend in ('OPTIX','CUDA'):
        try:
            pref.compute_device_type = backend
            pref.get_devices()
        except Exception:
            continue
        devices = [d for d in pref.devices if d.type == backend]
        if devices:
            for d in pref.devices:
                d.use = d.type == backend
            scene.cycles.device = 'GPU'
            return dict(backend=backend, devices=[d.name for d in devices])
    raise RuntimeError('GPU unavailable; explicitly use --device CPU for a CPU render.')


def framing(x):
    direction = np.array([3.,-4.,2.])
    direction /= np.linalg.norm(direction)
    right = np.cross(np.array([0.,0.,1.]),direction)
    right /= np.linalg.norm(right)
    up = np.cross(direction,right)
    center = (x.min(0)+x.max(0))/2
    local = x-center
    center += right*(np.min(local@right)+np.max(local@right))/2
    center += up*(np.min(local@up)+np.max(local@up))/2
    diag = float(np.linalg.norm(np.ptp(x,axis=0)))
    scale = float(1.16*max(np.ptp(x@right),np.ptp(x@up)))
    return dict(target=center.tolist(), position=(center+4*diag*direction).tolist(),
                ortho_scale=scale, bbox=[x.min(0).tolist(),x.max(0).tolist()],
                direction=direction.tolist(), right=right.tolist(), up=up.tolist(),
                light_scale=diag)


def setup_scene(frame, size, requested):
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.render.resolution_x = size
    scene.render.resolution_y = size
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.cycles.use_denoising = True
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.exposure = -.4
    world = bpy.data.worlds.new('Neutral preview world')
    scene.world = world
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs['Color'].default_value = (.45,.45,.45,1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value = .30
    cam_data = bpy.data.cameras.new('Shared actual geometry camera')
    camera = bpy.data.objects.new('Camera', cam_data)
    bpy.context.collection.objects.link(camera)
    scene.camera = camera
    camera.location = frame['position']
    camera.rotation_euler = (Vector(frame['target'])-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.type = 'ORTHO'
    camera.data.ortho_scale = frame['ortho_scale']
    camera.data.clip_end = max(100.,frame['light_scale']*20)
    center = np.array(frame['target'])
    direction,right,up = (np.array(frame[k]) for k in ('direction','right','up'))
    d = frame['light_scale']
    for name,offset,power in [('Key',3*direction-2*right+2.5*up,150),
                              ('Fill',2*direction+2*right+.5*up,45),
                              ('Rim',-direction+2*up,90)]:
        data = bpy.data.lights.new(name, 'AREA')
        data.energy = power*d*d
        data.shape = 'DISK'
        data.size = 1.7*d
        light = bpy.data.objects.new(name,data)
        bpy.context.collection.objects.link(light)
        light.location = center+d*offset
        light.rotation_euler = (Vector(center)-light.location).to_track_quat('-Z','Y').to_euler()
    return scene,select_device(scene,requested)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input',required=True)
    parser.add_argument('--output',required=True)
    parser.add_argument('--device',choices=['GPU','CPU'],default='GPU')
    parser.add_argument('--size',type=int,default=900)
    args = parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
    started = time.perf_counter()
    source,out = Path(args.input).resolve(),Path(args.output).resolve()
    if out.exists():
        raise FileExistsError('Output exists; choose a fresh directory to preserve previous renders.')
    source_sha = digest(source)
    with np.load(source,allow_pickle=False) as data:
        x = data['xyz'].copy()
        q = data['faces'].copy()
        weights = data['face_shape_weights'].copy()
        fixed = data['fixed_mask'].astype(bool)
        tissue = data['tissue_priority'].copy()
    if x.ndim != 2 or x.shape[1] != 3 or q.ndim != 2 or q.shape[1] != 4:
        raise ValueError('Expected xyz[N,3] and faces[M,4].')
    if weights.shape != (len(q),5) or fixed.shape != (len(x),) or tissue.shape != (len(x),):
        raise ValueError('Geometry/classification array dimensions differ.')
    if not np.isfinite(x).all() or not np.isfinite(weights).all() or not np.isfinite(tissue).all():
        raise ValueError('Nonfinite geometry or fields.')
    if np.min(q)<0 or np.max(q)>=len(x) or args.size<64:
        raise ValueError('Invalid indices or image size.')
    q = q.astype(np.int32)
    native = np.concatenate([x,x[q].mean(1)]).astype(np.float32)
    tri = np.empty((len(q),4,3),np.int32)
    tri[:,:,0] = q
    tri[:,:,1] = np.roll(q,-1,axis=1)
    tri[:,:,2] = (len(x)+np.arange(len(q)))[:,None]
    tri = tri.reshape(-1,3)
    labels = 1+np.argmax(weights,axis=1)
    labels[np.all(fixed[q],axis=1)] = 0
    frame = framing(x)
    scene,device = setup_scene(frame,args.size,args.device)
    mesh = bpy.data.meshes.new('Exact saved host native fans')
    mesh.vertices.add(len(native))
    mesh.vertices.foreach_set('co',native.ravel())
    mesh.loops.add(tri.size)
    mesh.loops.foreach_set('vertex_index',tri.ravel())
    mesh.polygons.add(len(tri))
    mesh.polygons.foreach_set('loop_start',np.arange(0,3*len(tri),3,dtype=np.int32))
    mesh.polygons.foreach_set('loop_total',np.full(len(tri),3,np.int32))
    mesh.polygons.foreach_set('use_smooth',np.zeros(len(tri),bool))
    obj = bpy.data.objects.new('Actual adaptive ornament result',mesh)
    bpy.context.collection.objects.link(obj)
    mesh.materials.append(material('Neutral gray clay',(.34,.36,.38,1)))
    before = geometry_signature(obj)
    if before['xyz_float32_sha256'] != array_hash(native) or before['faces_int32_sha256'] != array_hash(tri):
        raise ValueError('Native geometry readback differs from input arrays.')
    out.mkdir(parents=True)
    snapshot = out/'source_snapshot'
    snapshot.mkdir()
    shutil.copyfile(__file__,snapshot/Path(__file__).name)
    images = []
    for style,samples in [('gray',24),('color',8)]:
        if style == 'color':
            mesh.materials.clear()
            for i,rgba in enumerate(PALETTE):
                mesh.materials.append(material(LABELS[i],rgba))
            mesh.polygons.foreach_set('material_index',np.repeat(labels,4).astype(np.int32))
        scene.cycles.samples = samples
        png = out/(style+'.png')
        scene.render.filepath = str(png)
        bpy.ops.render.render(write_still=True)
        images.append(dict(style=style,path=str(png),sha256=digest(png),samples=samples))
    after = geometry_signature(obj)
    if before != after or before['edges'] or before['modifiers'] or not before['all_flat']:
        raise ValueError('Actual geometry changed or was smoothed by the renderer.')
    if digest(source) != source_sha:
        raise ValueError('Input geometry file changed during rendering.')
    result = dict(kind='GENERIC_ADAPTIVE_ORNAMENT_GEOMETRY_RENDER',prototype=True,
        input=str(source),input_sha256=source_sha,renderer_sha256=digest(__file__),
        control_vertices=len(x),quads=len(q),native_vertices=len(native),native_triangles=len(tri),
        input_array_sha256=dict(xyz=array_hash(x),quads=array_hash(q),face_shape_weights=array_hash(weights),
                               fixed_mask=array_hash(fixed),tissue_priority=array_hash(tissue)),
        before=before,after=after,unchanged_geometry=True,same_native_for_gray_and_color=True,
        all_flat=True,geometry_smoothing=False,normal_maps=False,camera=frame,device=device,
        images=images,resolution=[args.size,args.size],exposure=-.4,world_strength=.30,
        color_rule='Dominant original five shape weights; a face is gray only when all four input controls are fixed.',
        palette=[dict(index=i,label=label,rgba=list(rgba)) for i,(label,rgba) in enumerate(zip(LABELS,PALETTE))],
        face_class_counts=np.bincount(labels,minlength=6).tolist(),
        tissue_priority_range=[float(tissue.min()),float(tissue.max())],
        tissue_priority_color_override=False,
        limits=['Class colors show shape analysis, not feature birth or ornament height.',
                'Continuous Tissue blending remains in the supplied geometry; no arbitrary semantic Tissue mask is inferred.'],
        blender_version=bpy.app.version_string,elapsed_seconds=time.perf_counter()-started)
    (out/'RENDER_RECEIPT.json').write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
    print('GENERIC_HOST_GRAY_COLOR_READY',str(out),flush=True)


if __name__ == '__main__':
    main()
